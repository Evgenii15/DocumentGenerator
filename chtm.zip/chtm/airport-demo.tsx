import {getAirportByIATA} from '@apis/airport'

const defaultAirportCode = 'CDG';

app.screen('/', async(ctx,req) => {

  let airportCode = (req.query && req.query.code) ?? defaultAirportCode;

  let airport = await getAirportByIATA(airportCode);
  
  return <screen title={"Airport " + airportCode}>
    <search-input 
      name="code" 
      placeholder="Enter airport code"
      onChange={{url: ctx.router.url('search')}}
      initialValue={airportCode}
    />
    
    {! airport.error && <>
      <list-item content={{title: airport.name , subTitle: "Name" }}/>  
      <list-item content={{title: airport.iata , subTitle: "IATA" }}/>  
      <list-item content={{title: airport.location , subTitle: "Location" }}/>  
      <list-item content={{title: airport.country , subTitle: "Country" }}/>  
      <list-item content={{title: airport.phone , subTitle: "Phone" }}/>  
      <list-item content={{title: airport.website , subTitle: "Website" }}/>  
    </> }
  </screen>
}) 

app.apiCall('/search', async(ctx,req) => {
  return ctx.router.navigate(`/?code=${req.body.code}`, {replace: true})

})