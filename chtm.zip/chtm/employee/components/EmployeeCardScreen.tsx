import {jsx} from '@app/html-jsx'
import { Employees } from '../repo/Employees'
import { Button, Input, FormRow, Textarea,  Flex, ImagePicker, Container, FileUploader,  } from "@html/ui"
import {submitForm,refresh, showToast} from '@app/ui'
import { deleteEmployeeRoute, employeeAddRoute, employeeCardRoute, employeeIndexRoute, saveEmployeeModelRoute } from '../index'
import { DemoAppScreen } from './DemoAppScreen'
 
export async function EmployeeCardScreen({ctx, id} : {ctx: app.Ctx, id: string}) {

  let model = await Employees.getById(ctx, id)

  return <DemoAppScreen ctx={ctx}>

    <form method='post'>
      <h1 class={"text-4xl font-bold mb-2"}>{model.name}</h1>

      <FormRow label={ctx.t('Name')}>
        <Input name="name" value={model.name}/>
      </FormRow>

      <FormRow label="About"> 
        <Textarea rows={5} placeholder={ctx.t("Text about person")} name="about" value={model.about}/>
      </FormRow>

      <FormRow label="Avatar"> 
        <ImagePicker size={100} ctx={ctx} name="photo" hash={model.photo?.hash} />
      </FormRow>
      
      <Flex row justifyContent='space-between'>
        <div>
          <Button 
            type="submit" 
            onclick={submitForm({
              url:saveEmployeeModelRoute({id: model.id}).url()})
            } 
            style="margin-right: 10px;" primary>
              {ctx.t('Save')}
          </Button>
          <a href={employeeIndexRoute.url()}>{ctx.t('Back to list')}</a>
        </div>

        <Button 
          onclick={deleteEmployeeRoute.apiCall({id: model.id},{confirm: 'Are you sure?'})}
        >
          {ctx.t('Delete')}
        </Button>
      </Flex>

      
      

      
    </form>
  </DemoAppScreen>


}