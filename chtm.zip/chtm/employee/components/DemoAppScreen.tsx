// @shared

import {UiHtmlLayout} from '@html/layout'
import {Container} from '@html/ui'
import {jsx} from '@app/html-jsx'
import Style from './static/demo.css'


export function DemoAppScreen({ctx,} : {ctx: app.Ctx,}, ...children : any) {
  return <UiHtmlLayout title="Employees">
    <Style/>
    <Container width={'md'} padding='xl'>
      {children}
    </Container>
  </UiHtmlLayout>
}