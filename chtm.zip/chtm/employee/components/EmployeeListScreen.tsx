// @shared

import {createClientInitializer, jsx} from '@app/html-jsx'
import { Button, Input, ListItem, Flex, Container } from "@html/ui"
import {submitForm,refresh, showToast} from '@app/ui'
import { employeeAddRoute, employeeCardRoute } from '../index'
import {nanoid} from '@app/nanoid'
import { DemoAppScreen } from './DemoAppScreen'
import { Employee } from '../repo/Employees'
  
export async function EmployeeListScreen({ctx, models } : {ctx : app.Ctx, models: Employee[]}) {
  
  let ref = nanoid()
  
  return <DemoAppScreen ctx={ctx}>
    
    <div data-ref={ref}>
      <EmployeeListScreenInit ref={ref} ctx={ctx}/>
      <h1>{ctx.t('Employees')}</h1>

      <form method="post">
        <Flex row>
          <Input autofocus={'true'} data-name-input placeholder={ctx.t('Enter name')} name="name" required={"true"} style="margin-right: 10px"/>
          <Button onclick={submitForm({url: employeeAddRoute.url()})} type="submit" style="white-space:nowrap" primary>{ctx.t('Add employee')}</Button>
        </Flex>
      </form>
      <br/>

      {models.map( model =>
        <ListItem
          ctx={ctx}
          style={{marginBottom: '10px'}}
          data-employee-item
          data-name={model.name.toLowerCase()}
          icon={{ size: 'lg', circle:true, url: model.photo?.getThumbnailUrl(100), name: ['regular','user']}}
          onclick={employeeCardRoute({id:model.id}).navigate()}
          content={{title: model.name, subTitle: model.about ?? ''}}
        />
      )}
    </div>

  </DemoAppScreen>
}

export const EmployeeListScreenInit = createClientInitializer( ({ctx, element} : {ctx: jsx.Ctx, element: HTMLElement}) => {
  
  const inputElement = element.querySelector<HTMLInputElement>('[data-name-input]') !
  const employeeItems : HTMLElement[] = element.querySelectorAll('[data-employee-item]')
  
  inputElement.addEventListener( 'keyup' , (e : KeyboardEvent ) => {
    let searchString = e.target.value.toLowerCase()
    
    for( let employeeItemEl of employeeItems ) {
      if ( searchString == '' || employeeItemEl.dataset.name.includes(searchString) ) {
        employeeItemEl.classList.remove('__hidden')
      }
      else {
        employeeItemEl.classList.add('__hidden')
      }
    }
  })
  

})