// @shared
import {jsx} from '@app/html-jsx'
import { Employees } from './repo/Employees'
import {showToast} from '@app/ui'
import { EmployeeListScreen } from './components/EmployeeListScreen'
import { EmployeeCardScreen } from './components/EmployeeCardScreen'
 
export const employeeIndexRoute = app.html('/', async(ctx,req) => {
  let models = await Employees.findAll(ctx, {order: {name: 'asc'}})
  return <EmployeeListScreen ctx={ctx} models={models}/>
}) 

export const employeeCardRoute = app.html('/card/:id', async(ctx,req) => {
  return <EmployeeCardScreen ctx={ctx} id={req.params.id}/>
})
 
export const employeeAddRoute = app.apiCall('/add', async(ctx,req) => {

  let employee = await Employees.create(ctx,{
    name: req.body.name
  })

  return employeeCardRoute({id:employee.id}).navigate()
})


export const saveEmployeeModelRoute = app.apiCall('/save/:id', async(ctx,req) => {

  let employee = await Employees.getById(ctx, req.params.id);

  await Employees.update(ctx,{
    id: employee.id,
    name: req.body.name,
    photo: req.body.photo,
    about: req.body.about,
  })

  return showToast(ctx.t('Saved'));
})

export const deleteEmployeeRoute = app.apiCall('/delete', async(ctx,req) => {
  let model = await Employees.getById(ctx, req.body.id);
  if ( ! model ) {
    throw new Error('There is no model with ');
  }
  await Employees.delete(ctx,req.body.id)
  return employeeIndexRoute.navigate();
})