import {Heap} from '@app/heap'

export const Employees = Heap.Table('employees', {
  name: Heap.String(),
  photo: Heap.Nullable(Heap.ImageFile()),
  slug: Heap.Nullable(Heap.String()),
  about: Heap.Nullable(Heap.String()),
})

export type Employee = typeof Employees.T