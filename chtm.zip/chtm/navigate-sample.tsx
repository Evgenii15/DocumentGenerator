import { showContextMenu, showToast } from "@app/ui"

/**
 * Simple example of navigation beween two screens 
 */
 app.screen('/', function (ctx, req) {
  return (
    <screen title="Main screen">
        
        <button 
          class={["secondary", "section"]} 
          onClick={aboutRoute.navigate()}>
            <icon size={20} name={['fas','info-circle']} style={{color:'white'}}/> To about
        </button>

        <text class="section">What is your favorite color</text>
        
        <button 
          class={["primary", "section"]} 
          onClick={answerApiCall.apiCall({color: 'blue'}, {confirm: 'Are you sure?'})}>
            Blue
        </button>

        <button 
          class={["danger", "section"]} 
          onClick={answerApiCall.apiCall({color: 'red'})}>
            Red
        </button>

        

    </screen>
  )
})

/**
 * Here is a screen. 
 * First argument of app.screen is a subroute into file
 * Second argument is a handler returns <screen> tag
 */
const aboutRoute = app.screen('/about', function (ctx, req) {
  return (
    <screen title="About">
      
      <text class="section">
        Look at the address of the page - tilda is added as a suffix
      </text>

      <button class={["secondary","section"]} onClick={ctx.router.navigate('/')}>
        To main screen
      </button>

    </screen>
  )
})

/**
 * Here is a an apiCall 
 * First argument of app.apiCall is a subroute into file
 * Second argument is a handler returns one of ui-actions
 */
 const answerApiCall = app.apiCall('/message', async function (ctx, req) {
  if ( req.body.color === "red" ) {
    //return showToast(`Hello for ${req.body.color} likers`)
    return showContextMenu(
      [
        {title:'Rose', onClick: answerApiCall.apiCall({color: 'rose'})},
        {title:'Pink', onClick: answerApiCall.apiCall({color: 'pink'})},
        {title:'Coral', onClick: answerApiCall.apiCall({color: 'coral'})},
      ]
    )
  }
  else {
    return showToast(`Hello for ${req.body.color} likers`)
  }
})
