import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  let variant = req.query && req.query.variant
  const footerProps = variants[variant] || variants['default']

  ctx.t = v => v

  return (
    <screen title="">
      {Object.keys(variants).map(key => (
        <list-item
          content={{
            title: variants[key].title,
            subTitle: variants[key].subTitle,
          }}
          class={key === variant ? 'selected' : undefined}
          style={{ borderBottom: ['hairline', '#ddd'] }}
          onClick={ctx.router.navigate(`/?variant=${key}`, { replace: true })}
        />
      ))}
      <button
        title={ctx.t('Открыть этот экран в модальном окне')}
        onClick={ctx.router.navigate(`/?variant=${variant}`, { replace: true, openInModalScreen: true })}
      />
      <text style={{ height: 100, backgroundColor: '#ccc' }}>Текст, который не схлопывается по высоте {variant}</text>
      {variant !== 'default' && (
        <box style={{ height: 500, backgroundGradient: ['red', 'orange', 'green', 'blue'] }}>
          <text class="section">Бокс с большой высотой</text>
        </box>
      )}
      <footer {...footerProps} />

    </screen>
  )
})


const variants: Record<string, FooterAsyncProps & { title: string; subTitle?: string; onClickExtraOptions?: {} }> = {
  default: {
    title: 'Футер без стилей',
    subTitle: 'просто прозрачный бокс без отступов',
    blocks: [<text>Футер без стилей в самом низу несмотря на короткий контент</text>],
  },
  standard: {
    title: 'class=standard',
    subTitle: 'белый фон с блюром, отступы',
    class: 'standard',
    blocks: [
      <button class="success" onClick={showToast('Клик')}>
        Кнопка
      </button>,
    ],
  },
  margin: {
    title: 'marginTop/Horizontal,borderWidth/Radius/Color',
    subTitle: 'marginBottom не поддерживается',
    class: 'standard',
    style: {
      marginTop: 100,
      marginHorizontal: 50,
      borderTopLeftRadius: 10,
      borderTopRightRadius: 10,
      borderWidth: [1, 1, 0],
      borderColor: '#ddd',
    },
    blocks: [
      <button class="success" onClick={showToast('Клик')}>
        Кнопка
      </button>,
    ],
  },
  sizes: {
    title: 'height=100',
    subTitle: 'явный width не поддерживается',
    class: 'standard',
    style: {
      height: 100,
    },
    blocks: [
      <text>
        Много текста, Много текста, Много текста, Много текста, Много текста, Много текста, Много текста, Много текста,
        Много текста, Много текста, Много текста, Много текста, Много текста, Много текста, Много текста, Много текста,
        Много текста, Много текста, Много текста, Много текста, Много текста, Много текста, Много текста, Много текста,
      </text>,
    ],
  },
  buttons: {
    title: 'flexDir=row,justifyContent=space-evenly',
    subTitle: 'горизонтальный ряд кнопок',
    class: 'standard',
    style: {
      flexDirection: 'row',
      justifyContent: 'space-evenly',
      backgroundColor: '#ddd',
    },
    blocks: [
      <button class="success" onClick={showToast('Сохранить')}>
        Сохранить
      </button>,
      <button class="light" onClick={showToast('Отмена')}>
        Отмена
      </button>,
    ],
  },
}
