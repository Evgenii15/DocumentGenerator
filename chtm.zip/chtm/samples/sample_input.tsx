import { showToast, showContextMenu } from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="Input">
      <box class={['section']}>
        <text style={{ fontWeight: '700', marginBottom: 5 }}>Форма с валидацией</text>
        <text>One (&gt; 100)</text>
        <text-input autoFocus formId={'validate-form'} name={'one'} placeholder={'> 100'} initialValue={'30'} />

        <text style={{ marginTop: 20, marginBottom: 5 }}>Two (&lt; 50)</text>
        <text-input formId={'validate-form'} name={'two'} placeholder={'< 50'} initialValue={'200'} />

        <button
          class={['primary']}
          style={{ marginTop: 20 }}
          title={ctx.t('Submit form')}
          onClick={submitForm({
            formId: 'validate-form',
            url: ctx.account.url('/s/dev/chatium-json/blocks/api/validateForm'),
          })}
        />
      </box>

      <box class={['section']}>
        <text style={{ fontWeight: '700', marginBottom: 5 }}>Форма с разными полями</text>
        <text>field1</text>
        <text-input formId={'form'} name={'field1'} placeholder={'Заполните чем-то...'} />

        <text style={{ marginTop: 20, marginBottom: 5 }}>field2</text>
        <text-input
          formId={'form'}
          name={'field2'}
          style={{
            backgroundColor: '#eeeeee',
            color: 'gray',
            focus: {
              backgroundColor: '#00bdff3d',
              color: 'blue',
            },
          }}
          initialValue={'Input with onContext'}
          multiline
          onContext={showContextMenu([{ title: 'Context menu title', onClick: showToast('Clicked') }])}
        />

        <text style={{ marginTop: 20, marginBottom: 5 }}>firstName</text>
        <text-input
          formId={'form'}
          name={'firstName'}
          style={{
            focus: {
              color: 'green',
              border: [1, 'solid', 'green'],
              backgroundColor: '#e4f2e4',
            },
          }}
        />

        <text style={{ marginTop: 20, marginBottom: 5 }}>lastName</text>
        <text-input formId={'form'} name={'lastName'} initialValue={'Disabled input'} disabled />

        <text style={{ marginTop: 20, marginBottom: 5 }}>phone</text>
        <text-input
          formId={'form'}
          name={'one'}
          placeholder="phone"
          inputmode={'tel'}
          style={{
            backgroundGradient: ['to right', 'red', 'blue'],
            marginHorizontal: 50,
            border: [2, 'solid', 'red'],
            color: 'white',
            borderRadius: 8,
            textAlign: 'center',
          }}
          onChange={{
            url: ctx.account.url('/s/dev/chatium-json/blocks/api/validateForm'),
            params: {
              two: 10,
            },
          }}
        />

        <text style={{ marginTop: 20, marginBottom: 5 }}>email</text>
        <text-input formId={'form'} name={'email'} placeholder="email" inputmode={'email'} />

        <text style={{ marginTop: 20, marginBottom: 5 }}>decimal</text>
        <text-input formId={'form'} name={'decimal'} placeholder="decimal" inputmode={'decimal'} />

        <text style={{ marginTop: 20, marginBottom: 5 }}>url</text>
        <text-input formId={'form'} name={'url'} placeholder="url" inputmode={'url'} />
        <button
          class={['primary']}
          style={{ marginTop: 20 }}
          title={ctx.t('Submit form')}
          onClick={submitForm({
            formId: 'form',
            url: ctx.account.url('/s/dev/chatium-json/blocks/api/submitForm'),
            params: {
              fieldFromSubmitFormParams: 'Hello!',
            },
          })}
        />
      </box>

      <sticky style={{ padding: 10, backgroundColor: '#ddd' }}>
        <text-input formId={'sticky'} name={'sticky'} placeholder={'Input inside sticky block'} />
      </sticky>

      <box class={['section']}>
        <text style={{ fontWeight: '700', marginBottom: 5 }}>Форма с autoSubmit</text>
        <text>First name</text>
        <text-input
          formId={'formAutoSubmit'}
          name={'firstName'}
          placeholder={'onChange with showToast as action'}
          onChange={showToast('onChange triggered locally')}
        />

        <text>About</text>
        <text-input
          formId={'formAutoSubmit'}
          name={'about'}
          placeholder={'onChange with { url, params } and debounceOnChangeMs 2s'}
          multiline
          debounceOnChangeMs={2000}
          onChange={[
            submitForm({
              formId: 'formAutoSubmit',
              url: ctx.account.url('/s/dev/chatium-json/blocks/api/submitForm'),
              params: {
                additionalParams: 'Hello World!',
              },
            }),
          ]}
        />

        <button
          class={['primary']}
          style={{ marginTop: 20 }}
          title={ctx.t('Submit form')}
          onClick={submitForm({
            formId: 'formAutoSubmit',
            url: ctx.account.url('/s/dev/chatium-json/blocks/api/submitForm'),
          })}
        />
      </box>

      <text class={['section']} style={{ fontWeight: '700', marginTop: 30, marginBottom: 5 }}>
        Кастомная форма
      </text>
      <text-input
        class={['section']}
        name={'first'}
        formId={'custom-form'}
        initialValue={'Вот такой вот инпут'}
        style={{
          backgroundColor: '#dbdbdb',
          color: 'black',
          padding: [15, 30],
          borderRadius: 50,
          borderWidth: 0,
          focus: {
            backgroundColor: '#aeaeae',
          },
        }}
      />

      <text-input
        class={['section']}
        name={'second'}
        formId={'custom-form'}
        initialValue={'Еще один такой вот'}
        style={{
          backgroundColor: '#dbdbdb',
          color: 'black',
          padding: [15, 30],
          borderRadius: 50,
          borderWidth: 0,
          focus: {
            backgroundColor: '#aeaeae',
          },
        }}
      />

      <button
        class={['section', 'primary']}
        title={ctx.t('Submit form')}
        style={{
          color: 'white',
          padding: [15, 30],
          borderRadius: 50,
          backgroundColor: '#333333',
        }}
        onClick={submitForm({
          formId: 'custom-form',
          url: ctx.account.url('/s/dev/chatium-json/blocks/api/submitForm'),
        })}
      />

      <text>Явные размеры инпутов</text>
      <text-input multiline name={'f1'} formId={'f1'} placeholder={'width:100'} style={{ width: 100 }} />
      <text-input
        multiline
        name={'f2'}
        formId={'f1'}
        placeholder={'alignSelf: "center"'}
        style={{ width: 100, alignSelf: 'center' }}
      />
      <text-input
        multiline
        name={'f3'}
        formId={'f1'}
        placeholder={'alignSelf: "flex-end"'}
        style={{ width: 100, alignSelf: 'flex-end' }}
      />
      <text-input
        multiline
        name={'f4'}
        formId={'f1'}
        placeholder={'width: 25%'}
        style={{ width: '25%', alignSelf: 'flex-start' }}
      />
      <text-input
        multiline
        name={'f5'}
        formId={'f1'}
        placeholder={'width: 66%'}
        style={{ width: '66%', alignSelf: 'flex-start' }}
      />

      <text-input
        class={['section']}
        name={'first'}
        formId={'custom-form'}
        initialValue={'Вот такой вот инпут'}
        style={{
          backgroundColor: '#dbdbdb',
          color: 'black',
          padding: [15, 30],
          borderRadius: 50,
          borderWidth: 0,
          focus: {
            backgroundColor: '#aeaeae',
          },
        }}
      />

      <box style={{ paddingVertical: 10, backgroundColor: '#ece6da' }}>
        <text class={'section'}>resetFormAction & setFormInputAction</text>
        <text-input class={'section'} formId={'form-interop'} name={'name1'} placeholder={'name1'} />
        <text-input class={'section'} formId={'form-interop'} name={'name2'} placeholder={'name2'} />
        <button
          class={['section', 'secondary']}
          onClick={setFormInputValue({
            formId: 'form-interop',
            name: 'name1',
            value: 'value1',
            confirm: 'Вы уверены что хотите это сделать?',
          })}
        >
          set name1="value1"
        </button>
        <button
          class={['section', 'secondary']}
          onClick={setFormInputValue({ formId: 'form-interop', name: 'name2', value: 'value2' })}
        >
          set name2="value2"
        </button>
        <button
          class={['section', 'danger']}
          onClick={resetForm({ formId: 'form-interop', confirm: 'Вы уверены что хотите это сделать?' })}
        >
          Reset form
        </button>
        <button
          class={['section', 'primary']}
          onClick={submitForm({
            formId: 'form-interop',
            url: ctx.account.url('/s/dev/chatium-json/blocks/api/submitForm'),
            confirm: 'Действительно отправить форму?',
          })}
        >
          Отправить
        </button>
      </box>

      <box style={{ height: 1000, backgroundGradient: ['to top', 'red', 'green', 'blue'] }} />

      <text-input
        class={['section']}
        name={'first'}
        formId={'custom-form'}
        initialValue={'Вот такой вот инпут'}
        style={{
          backgroundColor: '#dbdbdb',
          color: 'black',
          padding: [15, 30],
          borderRadius: 50,
          borderWidth: 0,
          focus: {
            backgroundColor: '#aeaeae',
          },
        }}
      />

      <footer style={{ padding: 10, backgroundColor: 'rgba(255, 255, 255, 0.98)', borderTop: ['hairline', 'black'] }}>
        <text-input formId={'footerForm'} placeholder={'Инпут в футере'} name={'name1'} />
      </footer>
    </screen>
  )
})


function submitForm(props) {
  return { type: 'submitForm', ...props }
}

function setFormInputValue(props) {
  return { type: 'setFormInputValue', ...props }
}

function setFormInputAction(props) {
  return { type: 'setFormInputAction', ...props }
}

function resetForm(props) {
  return { type: 'resetForm', ...props }
}
