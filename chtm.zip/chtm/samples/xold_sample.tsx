import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="">
      
    </screen>
  )
})
