import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="">
      <header
        title={ctx.t('Блоки > {type}', { type: 'AUDIO' })}
        rightButton={{ onClick: showToast('header button') }}
      />

      <text>Аудио-блок</text>
      <audio src={{ url: AUDIO_TRACKS[0].url }} title={AUDIO_TRACKS[0].title} subTitle={AUDIO_TRACKS[0].subTitle} />

      <text>+class=section</text>
      <audio
        src={{ url: AUDIO_TRACKS[0].url, durationSeconds: AUDIO_TRACKS[0].durationSeconds }}
        title={AUDIO_TRACKS[0].title}
        subTitle={AUDIO_TRACKS[0].subTitle}
        class={'section'}
      />

      <text>{ctx.t('Демо автопаузы между видео и аудио')}</text>
      <video
        src={{
          hls: 'https://videodelivery.net/4243f17ac5144313acca1eb3530a7995/manifest/video.m3u8',
        }}
        style={{ height: 100, alignSelf: 'center' }}
      />

      <text>+opacity = 0.5</text>
      <audio
        src={{ url: AUDIO_TRACKS[1].url }}
        title={AUDIO_TRACKS[1].title}
        subTitle={AUDIO_TRACKS[1].subTitle}
        class={'section'}
        style={{ opacity: 0.5 }}
      />

      <text>src.durationSeconds = 3</text>
      <audio
        src={{ url: AUDIO_TRACKS[2].url, durationSeconds: 3 }}
        title={
          AUDIO_TRACKS[2].title +
          ' ' +
          AUDIO_TRACKS[2].title +
          ' ' +
          AUDIO_TRACKS[2].title +
          ' ' +
          AUDIO_TRACKS[2].title +
          ' '
        }
        subTitle={
          AUDIO_TRACKS[2].subTitle +
          ' ' +
          AUDIO_TRACKS[2].subTitle +
          ' ' +
          AUDIO_TRACKS[2].subTitle +
          ' ' +
          AUDIO_TRACKS[2].subTitle +
          ' '
        }
        class={'section'}
      />

      <text>+onContext</text>
      <audio
        src={{ url: AUDIO_TRACKS[3].url, durationSeconds: AUDIO_TRACKS[3].durationSeconds }}
        title={AUDIO_TRACKS[3].title}
        subTitle={AUDIO_TRACKS[3].subTitle}
        class={'section'}
        onContext={showToast('Контекст на аудио блоке')}
      />

      <text>+customColor & background & padding</text>
      <audio
        src={{ url: AUDIO_TRACKS[4].url, durationSeconds: AUDIO_TRACKS[4].durationSeconds }}
        title={AUDIO_TRACKS[4].title}
        subTitle={AUDIO_TRACKS[4].subTitle}
        class={'section'}
        onContext={showToast('Контекст на аудио блоке')}
        style={{
          backgroundGradient: ['to right', '#aaa', '#eee'],
          padding: 10,
          color: 'blue',
        }}
      />
    </screen>
  )
})




const AUDIO_TRACKS = [
  {
    url: 'https://fs.chatium.io/fileservice/file/download/h/audio_LRJ8Kzjqg1.d187.mp3',
    title: 'На машине марки ВАЗ',
    durationSeconds: 186,
  },
  {
    url: 'https://fs.chatium.io/fileservice/file/download/h/audio_BnTsIqjXJK.d365.mp3',
    title: 'Cloches',
    subTitle: 'Worakls',
    durationSeconds: 364,
  },
  {
    url: 'https://fs.chatium.io/fileservice/file/download/h/audio_MlI716Gujy.d533.mp3',
    title: 'Shine (wAFF Sunrise Mix)',
    subTitle: 'Digitaria',
    durationSeconds: 532,
  },
  {
    url: 'https://fs.chatium.io/fileservice/file/download/h/audio_Mmm0BigUpy.d600.mp3',
    title: 'Lingala (feat. Junior)',
    subTitle: 'Lee Burridge & Lost Desert',
    durationSeconds: 599,
  },
  {
    url: 'https://fs.chatium.io/fileservice/file/download/h/audio_nY9R7VVADu.d236.mp3',
    title: "Dance D'amour",
    subTitle: 'The 69 Eyes',
    durationSeconds: 235,
  },
]