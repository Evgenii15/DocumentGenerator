import {showToast} from '@chatium/json'

/**
 * Это пример вызова apiCall
 * В пределах одного файла - мы объявляем 2 "адреса"
 * 
 * / - это файл с главной страницей
 * .apiCall - это адрес "действия" (обратите внимание что это не .screen, а .apiCall )
 * 
 * мы можем вызвать действие через ctx.router.apiCall
 * если мы хотим вызвать действие из другого файла - мы можем использовать ctx.account.apiCall('и указать прямой адрес на нашу страницу')
 * 
 * Возможные действия - в следующем файле 4_actions.tsx
 * 
 */
app.screen('/', function (ctx, req) {
  return (
    <screen title="Основной экран">
    <section>
      <button
        class="primary" onClick={ctx.router.apiCall('/hello')}>
          Вызвать действие
        </button>
        </section>
    </screen>
  )
})

/**
 * Адрес действия
 */
app.apiCall('/hello', function (ctx, req) {
  return [
    showToast('Hello')
  ]
})
