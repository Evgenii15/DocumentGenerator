import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  let query = req.query.query

  ctx.t = v => v
  if (query) {
    ctx.resp.header('Cache-Control', 'no-store')
  }

  return (
    <screen title="">
      <sticky>
        <search-input
          name={'value'}
          formId={'f1'}
          placeholder={'Type for searching...'}
          onChange={{
            url: ctx.account.url('/s/dev/chatium-json/blocks/api/search'),
            params: {
              salt: Math.round(Math.random() * 100000),
            },
          }}
          initialValue={query}
        />
      </sticky>
      <sticky>
        <search-input
          name={'value'}
          formId={'f2'}
          class={['section']}
          placeholder={'Type for searching...'}
          initialValue={query}
          onChange={{
            url: ctx.account.url('/s/dev/chatium-json/blocks/api/search'),
            params: {
              salt: Math.round(Math.random() * 100000),
            },
          }}
        />
      </sticky>
      <sticky>
        <text-input
          name={'value'}
          formId={'f3'}
          class={['section']}
          placeholder={'Just a text, without autosubmit (useless for Web)'}
          returnKeyType={'search'}
          initialValue={query}
          onReturnKeyPress={{
            url: ctx.account.url('/s/dev/chatium-json/blocks/api/search'),
            params: {
              salt: Math.round(Math.random() * 100000),
            },
          }}
        />
      </sticky>
      <text>Page generated at {new Date().toISOString()}</text>
      {query ? <text>Search results for {query}:</text> : <text>Please enter search query</text>}
      {query
        ? Array.from(Array(Math.round(Math.random() * 30) + 5).keys()).map(index => (
          <text key={'search-res-' + index}>{index + 1 + '. ' + query}</text>
        ))
        : null}
      <box id={'results'} class={['section']} />
    </screen>
  )
})
