import {showContextMenu, showToast} from '@chatium/json'

app.screen('/', function (ctx, req) {
  return (
    <screen title="Hello world!">
      <text text={'Это просто текст'} />

      <text>
        Справа должно быть число: <text>{123}</text>
      </text>

      <text class={'link'} onClick={ctx.account.url('s/dev/chatium-json')}>
        Это ссылка
      </text>

      <text class={['link', 'section']} onClick={showToast('Вы нажали на ссылку-секцию')}>
        Это ссылка-секция
      </text>

      <text class={['link', 'section']} style={{ padding: 10 }} onClick={showToast('Вы нажали на ссылку-секцию')}>
        Это ссылка-секция, но с дополнительными паддингами
      </text>

      <text
        class={'section'}
        onContext={showContextMenu([{ title: 'Действие', onClick: showToast('Действие') }])}
      >
        Это текст - секция с контекстным меню
      </text>

      <text class={'section'} style={{ backgroundColor: '#ddd' }}>
        Это текст - секция, с добавлением фона
      </text>

      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10 }}>
        Это текст - секция, с добавлением фона, и паддингов сверху и снизу
      </text>

      <text class={'section'} style={{ backgroundColor: '#ddd' }}>
        Это текст - секция, с добавлением фона, и добавлением вложенных текстов, которые показывают разные размеры:
        {'\n'}
        <text style={{ fontSize: 60 }}>fontSize: 60</text>
        {'\n'}
        <text style={{ fontSize: '3xl' }}>3xl</text>
        {'\n'}
        <text style={{ fontSize: '2xl' }}>2xl</text>
        {'\n'}
        <text style={{ fontSize: 'xl' }}>xl</text>
        {'\n'}
        <text style={{ fontSize: 'lg' }}>lg</text>
        {'\n'}
        <text style={{ fontSize: 'md' }}>md</text>
        {'\n'}
        <text style={{ fontSize: 'sm' }}>sm</text>
        {'\n'}
        <text style={{ fontSize: 'xs' }}>xs</text>
        {'\n'}
      </text>

      <text style={{ fontSize: 60 }}>
        <text>fontSize: 60</text>
      </text>

      <text class={'section'} style={{ backgroundColor: '#ddd' }}>
        Разные цвета текста:
        {'\n'}
        <text style={{ color: 'red' }}>red</text>
        {'\n'}
        <text style={{ color: 'green' }}>green</text>
        {'\n'}
        <text style={{ color: 'blue' }}>blue</text>
        {'\n'}
        <text style={{ color: 'rgb(12,137,221)' }}>rgb(12,137,221)</text>
        {'\n'}
        <text style={{ color: 'rgba(12,137,221, 0.6)' }}>rgba(12,137,221, 0.6)</text>
      </text>

      <text class={'section'} style={{ backgroundColor: '#ddd' }}>
        Разные фоны текста:
        {'\n'}
        <text style={{ backgroundColor: 'red' }}>red</text>
        {'\n'}
        <text style={{ backgroundColor: 'green' }}>green</text>
        {'\n'}
        <text style={{ backgroundColor: 'blue' }}>blue</text>
        {'\n'}
        <text style={{ backgroundColor: 'rgb(12,137,221)' }}>rgb(12,137,221)</text>
        {'\n'}
        <text style={{ backgroundColor: 'rgba(12,137,221, 0.6)' }}>rgba(12,137,221, 0.6)</text>
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        lineClamp: 2 (в мобиле троеточие не показывается, если текст обрезается не посреди строки, а во время явного
        переноса строки)
      </text>
      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10, lineClamp: 2 }}>
        Тут должно быть две строки (хотя в json - 3):{'\n'}Это вторая строка{'\n'}А это третья (быть не должно)
      </text>
      <text class={'section'} style={{ marginBottom: 0 }}>
        lineClamp: 1
      </text>
      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10, lineClamp: 1 }}>
        Это очень длинная <text style={{ fontWeight: 'bold' }}>строка</text>, которая не уместится в мобильном
        приложении в одну строку, и должна обрезаться справа
      </text>
      <text class={'section'} style={{ marginBottom: 0 }}>
        lineClamp: 1, textOverflow: 'clip' (работает только для lineClamp == 1)
      </text>
      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10, lineClamp: 1, textOverflow: 'clip' }}>
        <text style={{ fontStyle: 'italic' }}>
          Это очень длинная строка, которая не уместится в мобильном приложении в одну строку, и должна обрезаться
          справа
        </text>
        <text style={{ fontWeight: 'bold' }}>Супер пупер оформленный текст</text>
      </text>
      <text class={'section'} style={{ marginBottom: 0 }}>
        lineClamp: 2, textOverflow: 'clip' (clip НЕ работает для lineClamp {'>'} 1)
      </text>
      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10, lineClamp: 2, textOverflow: 'clip' }}>
        <text style={{ fontStyle: 'italic' }}>
          Это очень длинная строка, которая не уместится в мобильном приложении в одну строку, и должна обрезаться
          справа
        </text>
        <text style={{ fontWeight: 'bold' }}>Супер пупер оформленный текст</text>
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        пробелы в начале
      </text>
      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10 }}>
        {'   '}Тут три пробела в начале
      </text>

      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10 }}>
        {'Это текст с переносом\n<- вот тут посреди строки'}
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        fontVariant
      </text>
      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10 }}>
        <text>normal:{'\n'}0123456789</text>
        {'\n'}
        <text style={{ fontVariant: ['tabular-nums'] }}>tabular-nums:{'\n'}0123456789</text>
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        letterSpacing
      </text>
      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10 }}>
        <text>1:</text>
        {'\n'}
        <text style={{ letterSpacing: 1 }}>0123456789</text>
        {'\n'}
        <text>2:</text>
        {'\n'}
        <text style={{ letterSpacing: 2 }}>0123456789</text>
        {'\n'}
        <text>3:</text>
        {'\n'}
        <text style={{ letterSpacing: 3 }}>0123456789</text>
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        textTransform
      </text>
      <text class={'section'} style={{ backgroundColor: '#ddd', padding: 10 }}>
        <text>none: </text>
        <text style={{ textTransform: 'none' }}>abc dEf ghj</text>
        {'\n'}
        <text>capitalize: </text>
        <text style={{ textTransform: 'capitalize' }}>abc dEf ghj</text>
        {'\n'}
        <text>lowercase: </text>
        <text style={{ textTransform: 'lowercase' }}>abc dEf ghj</text>
        {'\n'}
        <text>uppercase: </text>
        <text style={{ textTransform: 'uppercase' }}>abc dEf ghj</text>
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        textShadow
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
          textShadowColor: 'cyan',
          textShadowOffset: { width: 5, height: 5 },
          textShadowRadius: 5,
        }}
      >
        Этот текст должен быть с тенью
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        opacity
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
          opacity: 0.5,
        }}
      >
        Полупрозрачный текст
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        textDecorationLine
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
        }}
      >
        none: <text style={{ textDecorationLine: 'none' }}>это пример текста</text>
        {'\n'}
        line-through: <text style={{ textDecorationLine: 'line-through' }}>это пример текста</text>
        {'\n'}
        underline: <text style={{ textDecorationLine: 'underline' }}>это пример текста</text>
        {'\n'}
        underline line-through: <text style={{ textDecorationLine: 'underline line-through' }}>это пример текста</text>
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        fontStyle
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
        }}
      >
        normal: <text style={{ fontStyle: 'normal' }}>это пример текста</text>
        {'\n'}
        italic: <text style={{ fontStyle: 'italic' }}>это пример текста</text>
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        fontWeight
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
        }}
      >
        normal: <text style={{ fontWeight: 'normal' }}>это пример текста</text>
        {'\n'}
        bold: <text style={{ fontWeight: 'bold' }}>это пример текста</text>
        {'\n'}
        100: <text style={{ fontWeight: '100' }}>это пример текста</text>
        {'\n'}
        200: <text style={{ fontWeight: '200' }}>это пример текста</text>
        {'\n'}
        300: <text style={{ fontWeight: '300' }}>это пример текста</text>
        {'\n'}
        400: <text style={{ fontWeight: '400' }}>это пример текста</text>
        {'\n'}
        500: <text style={{ fontWeight: '500' }}>это пример текста</text>
        {'\n'}
        600: <text style={{ fontWeight: '600' }}>это пример текста</text>
        {'\n'}
        700: <text style={{ fontWeight: '700' }}>это пример текста</text>
        {'\n'}
        800: <text style={{ fontWeight: '800' }}>это пример текста</text>
        {'\n'}
        900: <text style={{ fontWeight: '900' }}>это пример текста</text>
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        textAlign=auto
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
          textAlign: 'auto',
        }}
      >
        Это пример текста для выравнивания
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        textAlign=center
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
          textAlign: 'center',
        }}
      >
        Это пример текста для выравнивания
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        textAlign=left
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
          textAlign: 'left',
        }}
      >
        Это пример текста для выравнивания
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        textAlign=right
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
          textAlign: 'right',
        }}
      >
        Это пример текста для выравнивания
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        textAlign=justify
      </text>
      <text
        class={'section'}
        style={{
          backgroundColor: '#ddd',
          padding: 10,
          textAlign: 'justify',
        }}
      >
        Это пример текста для выравнивания, очень длинный, такой длинный что точно не влезет в одну строку и перенесётся
        для показа выравнивания по двум сторонам
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        alignSelf
      </text>
      <text style={{ padding: 10, backgroundColor: '#ddd', alignSelf: 'auto' }}>auto</text>
      <text style={{ padding: 10, backgroundColor: '#ddd', alignSelf: 'stretch' }}>stretch</text>
      <text style={{ padding: 10, backgroundColor: '#ddd', alignSelf: 'center' }}>center</text>
      <text style={{ padding: 10, backgroundColor: '#ddd', alignSelf: 'baseline' }}>baseline</text>
      <text style={{ padding: 10, backgroundColor: '#ddd', alignSelf: 'flex-end' }}>flex-end</text>
      <text style={{ padding: 10, backgroundColor: '#ddd', alignSelf: 'flex-start' }}>flex-start</text>

      <text class={'section'} style={{ marginTop: 20, marginBottom: 0 }}>
        position
      </text>
      <text style={{ padding: 10, backgroundColor: '#ddd', left: 0 }}>left: 0</text>
      <text style={{ padding: 10, backgroundColor: '#ddd', left: '50%' }}>left: 50%</text>
      <text style={{ padding: 10, backgroundColor: '#ddd', right: 0 }}>right: 0</text>
      <text style={{ padding: 10, backgroundColor: '#ddd', right: '50%' }}>right: 50%</text>

      <text class={'section'} style={{ marginTop: 20, marginBottom: 0 }}>
        width
      </text>
      <text style={{ marginLeft: 10, paddingVertical: 10, backgroundColor: '#ddd', width: 10 }}>10</text>
      <text style={{ marginLeft: 10, paddingVertical: 10, backgroundColor: '#ddd', width: 20 }}>20</text>
      <text style={{ marginLeft: 10, paddingVertical: 10, backgroundColor: '#ddd', width: 30 }}>30</text>
      <text style={{ marginLeft: 10, paddingVertical: 10, backgroundColor: '#ddd', width: '10%' }}>10%</text>
      <text style={{ marginLeft: 10, paddingVertical: 10, backgroundColor: '#ddd', width: '20%' }}>20%</text>
      <text style={{ marginLeft: 10, paddingVertical: 10, backgroundColor: '#ddd', width: '30%' }}>30%</text>
      <text style={{ marginLeft: 10, paddingVertical: 10, backgroundColor: '#ddd', width: '40%' }}>40%</text>

      <text class={'section'} style={{ marginTop: 20, marginBottom: 0 }}>
        onClick
      </text>
      <text
        style={{
          padding: 10,
          backgroundColor: '#ddd',
          active: { backgroundColor: 'blue', color: 'white', opacity: 0.3 },
        }}
        onClick={showToast('Вы нажали на текст')}
        onContext={showToast('Вы нажали правой кнопкой/долгим тапом')}
      >
        Этот текст нажимается с красивой анимацией
      </text>

      <text class={'section'} style={{ marginTop: 20, marginBottom: 0 }}>
        onContext на вложенные элементы
      </text>
      <text
        style={{
          padding: 10,
          backgroundColor: '#ddd',
          active: { backgroundColor: 'blue', color: 'white', opacity: 0.3 },
        }}
        onClick={showToast('Вы нажали на внешний текст')}
        onContext={showToast('Вы нажали правой кнопкой/долгим тапом на внешнем тексте')}
      >
        Сам этот текст нажимается{'\n\n'}
        <text onClick={showToast('Вы нажали на внутренний текст 1')}>
          Этот текст нажимается отдельно, но долгий тап по нему должен пробрасываться наверх{'\n\n'}
        </text>
        <text
          onClick={showToast('Вы нажали на внутренний текст 2')}
          onContext={showToast('Вы нажали правой кнопкой/долгим тапом на текст 2')}
          class="link"
        >
          Этот текст нажимается отдельно и показан в виде ссылки, и долгий тап тоже отдельно
        </text>
        {'\n\n'}
        <text>Это просто вложенный текст, должен нажиматься тоже</text>
      </text>

      <text class={'section'} style={{ marginTop: 20, marginBottom: 0 }}>
        onClick, nested texts
      </text>
      <text style={{ padding: 10, backgroundColor: '#ddd' }}>
        Это просто текст внутри, и со ссылками:{' '}
        <text
          style={{ textDecorationLine: 'underline', active: { backgroundColor: 'blue', color: 'white', opacity: 0.3 } }}
          onClick={showToast('Вы нажали на текст')}
        >
          Это ссылка
        </text>{' '}
        а вот это text(class=link):{' '}
        <text class={'link'} onClick={'https://chatium.com'}>
          ссылка с классом
        </text>
      </text>

      <text class={'section'} style={{ marginTop: 20, marginBottom: 0 }}>
        text with formatting
      </text>
      <text style={{ padding: 10, backgroundColor: '#ddd' }}>
        Это текст,{' '}
        <text style={{ fontWeight: 'bold' }}>
          а это жирный,{' '}
          <text style={{ fontStyle: 'italic' }}>
            а это ещё и курсивный,{' '}
            <text style={{ color: 'red' }}>
              а этот до кучи красный, <text style={{ textDecorationLine: 'underline' }}>а этот мы подчеркнём</text>
            </text>
          </text>
        </text>
      </text>

      <text class={'section'} style={{ marginTop: 20, marginBottom: 0 }}>
        fontFamily
      </text>
      <text style={{ padding: 10, backgroundColor: '#ddd' }}>
        <text style={{ fontFamily: 'sans' }}>
          Sans, <text style={{ fontStyle: 'italic' }}>Italic</text>{' '}
          <text style={{ fontWeight: 'bold' }}>
            Bold, <text style={{ fontStyle: 'italic' }}>Italic Bold</text>
          </text>
        </text>
        {'\n'}
        <text style={{ fontFamily: 'serif' }}>
          Serif, <text style={{ fontStyle: 'italic' }}>Italic</text>{' '}
          <text style={{ fontWeight: 'bold' }}>
            Bold, <text style={{ fontStyle: 'italic' }}>Italic Bold</text>
          </text>
        </text>
        {'\n'}
        <text style={{ fontFamily: 'mono' }}>
          Monospace, <text style={{ fontStyle: 'italic' }}>Italic</text>{' '}
          <text style={{ fontWeight: 'bold' }}>
            Bold, <text style={{ fontStyle: 'italic' }}>Italic Bold</text>
          </text>
        </text>
      </text>

      <text class={'section'} style={{ marginTop: 20, marginBottom: 0 }}>
        code example
      </text>
      <horizontal-scroll style={{ backgroundColor: '#ddd', padding: 10 }} showScrollBar={true}>
        <text
          style={{ fontFamily: 'mono' }}
          text={`function formatSeconds(seconds) {
  const minutesStr = String(Math.floor(seconds / 60)).padStart(2, "0");
  const secondsStr = String(Math.floor(seconds % 60)).padStart(2, "0");
  return minutesStr + ":" + secondsStr;
}`}
        />
      </horizontal-scroll>
    </screen>
  )
})
