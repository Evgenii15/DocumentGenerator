import { showToast } from '@chatium/json'


const variants = {
  default: {
    title: 'hls 1 + poster + compact',
    props: {
      src: { hls: 'https://videodelivery.net/b3c38a8386564212af7490a9de6b838b/manifest/video.m3u8' },
      poster: 'https://fs.chatium.io/fileservice/file/thumbnail/h/video_Bor8Y47Gbt.d30.3840x2160.m4v/s/800x',
    },
  },
  hls2: {
    title: 'hls 2 + full',
    props: {
      src: { hls: 'https://videodelivery.net/4243f17ac5144313acca1eb3530a7995/manifest/video.m3u8' },
      controls: 'full',
    },
  },
  mp4: {
    title: 'mp4 + poster + mini',
    props: {
      src: { mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/hNSeEcm69CqhEv3MyZy4fJ/mp4/480.mp4' },
      poster: 'https://fs.chatium.io/fileservice/file/thumbnail/h/video_aB1Skpxfkw.d51.720x1280.m4v/s/800x',
      controls: 'mini',
    },
  },
}

app.screen('/', function (ctx, req) {

  ctx.t = v => v
  let variant = req.query && req.query.variant;
  const currentVar = variants[variant] ?? variants.default

  return (
    <screen title="Video">
      <header
        mode="parallax"
        title={ctx.t('Блоки > {type}', { type: 'VIDEO' })}
        transparentStyle={{
          color: '#fff',
          backgroundGradient: ['to bottom', 'rgba(0,0,0,0.5)', 'rgba(0,0,0,0)'],
        }}
      />
      <parallax
        background={
          <video
            src={{
              mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/hdt1u7cbg4wLV7dw8azu7s/mp4/480.mp4',
            }}
            controls="none"
            style={{ height: 300 }}
            autoplay
            muted
            loop
          />
        }
        content={[
          <box
            style={{
              position: 'absolute',
              bottom: 0,
              width: '100%',
              backgroundGradient: ['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0.5)'],
            }}
          >
            <text style={{ padding: 20, color: '#fff', fontSize: 'xl' }}>
              {ctx.t('Блоки > {type}', { type: 'VIDEO' })}
            </text>
          </box>,
        ]}
      />

      {/*<list-item*/}
      {/*  content={{*/}
      {/*    title: 'Автовоспроизведение',*/}
      {/*    subTitle: 'Пример автопереключения видео по скроллу',*/}
      {/*  }}*/}
      {/*  onClick={ctx.account.navigate(`/s/dev/chatium-json/blocks/video/autoplay`)}*/}
      {/*/>*/}

      <text class="section">
        class=section style.backgroundGradient=[45,green,yellow] style.borderRadius=10 style.border=[2,dashed,red]
        onContext
      </text>
      <video
        class="section"
        src={{
          hls: 'https://videodelivery.net/88906b1d343e46ba94e98979625b42f0/manifest/video.m3u8',
        }}
        autoplay
        style={{
          borderRadius: 10,
          border: [2, 'dashed', 'red'],
          backgroundGradient: [45, 'green', 'yellow'],
        }}
        onContext={showToast('Контекст на видео')}
        onVideoEnd={showToast('Видео закончилось')}
      />

      <Example title={ctx.t('Размеры видео без постера')}>
        <text>{ctx.t('Совсем никакие размеры не заданы, controls=full, mp4')}</text>
        <video
          src={{
            mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/m3ByjYoei923fyE3Eep7DV/mp4/480.mp4',
          }}
          controls="full"
        />
        <text>style.width=200 controls=compact, hls</text>
        <video
          src={{ hls: 'https://videodelivery.net/88906b1d343e46ba94e98979625b42f0/manifest/video.m3u8' }}
          controls="compact"
          style={{ width: 200 }}
        />
        <text>style.height=150 controls=mini, hls+mp4</text>
        <video
          src={{
            hls: 'https://videodelivery.net/88906b1d343e46ba94e98979625b42f0/manifest/video.m3u8',
            mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/m3ByjYoei923fyE3Eep7DV/mp4/480.mp4',
          }}
          controls="mini"
          style={{ height: 150 }}
        />
        <text>src.width=200 src.height=200 controls=none</text>
        <video
          src={{
            hls: 'https://videodelivery.net/88906b1d343e46ba94e98979625b42f0/manifest/video.m3u8',
            width: 200,
            height: 200,
          }}
          controls="none"
        />
      </Example>

      <Example title={ctx.t('Размеры видео с постером')}>
        <text>{ctx.t('Совсем никакие размеры не заданы, controls=full muted')}</text>
        <video
          src={{
            mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/hNSeEcm69CqhEv3MyZy4fJ/mp4/480.mp4',
          }}
          poster="https://fs.chatium.io/fileservice/file/thumbnail/h/video_aB1Skpxfkw.d51.720x1280.m4v/s/800x"
          controls="full"
          muted
        />
        <text>То же самое без постера</text>
        <video
          src={{
            mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/hNSeEcm69CqhEv3MyZy4fJ/mp4/480.mp4',
          }}
        />
        <text>style.width=250</text>
        <video
          src={{
            mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/hNSeEcm69CqhEv3MyZy4fJ/mp4/480.mp4',
          }}
          poster="https://fs.chatium.io/fileservice/file/thumbnail/h/video_aB1Skpxfkw.d51.720x1280.m4v/s/800x"
          style={{ width: 250 }}
        />
        <text>style.height=250</text>
        <video
          src={{
            mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/hNSeEcm69CqhEv3MyZy4fJ/mp4/480.mp4',
          }}
          poster="https://fs.chatium.io/fileservice/file/thumbnail/h/video_aB1Skpxfkw.d51.720x1280.m4v/s/800x"
          style={{ height: 250 }}
        />
        <text>style.width=200 style.height=200</text>
        <video
          src={{
            mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/hNSeEcm69CqhEv3MyZy4fJ/mp4/480.mp4',
          }}
          poster="https://fs.chatium.io/fileservice/file/thumbnail/h/video_aB1Skpxfkw.d51.720x1280.m4v/s/800x"
          style={{ width: 200, height: 200 }}
        />
        <text>src.width=180 src.height=320</text>
        <video
          src={{
            mp4: 'https://videos-8b305284-cdn-integros-com.akamaized.net/videos/hNSeEcm69CqhEv3MyZy4fJ/mp4/480.mp4',
            width: 180,
            height: 320,
          }}
          poster="https://fs.chatium.io/fileservice/file/thumbnail/h/video_aB1Skpxfkw.d51.720x1280.m4v/s/800x"
        />
      </Example>

      <Example title={ctx.t('Обновление исходника видео')}>
        <box>
          {Object.keys(variants).map(key => (
            <list-item
              content={{
                title: variants[key].title,
              }}
              class={key === variant ? 'selected' : null}
              style={{ borderBottom: ['hairline', '#ddd'] }}
              onClick={ctx.router.navigate(`?variant=${key}`, { replace: true })}
            />
          ))}
        </box>
        <video {...currentVar.props} />
      </Example>

    </screen>
  )
})




function Example({ title, containerStyle }, ...children) {
  return (
    <>
      <text style={{ fontSize: 'md', fontWeight: '600', paddingHorizontal: 10 }}>{title}</text>
      <box style={{ backgroundColor: '#ddd', padding: 10, marginBottom: 15, ...containerStyle }}>{children}</box>
    </>
  )
}

