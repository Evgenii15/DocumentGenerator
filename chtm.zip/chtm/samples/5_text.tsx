
/**
 * Примеры текстового блока <text></text>
 */
app.screen('/', function (ctx, req) {
  return (
    <screen title="text">

      {/* Текст. Самый простой блок. Теги типа <p><b> - это тоже текстовые блоки, с заданным стилем */}
      <text>Обычный текстовый блок, без отступов</text>

      {/* Текстовый блок поддерживает стили */}
      <text style={{ fontSize: 12, fontWeight: 'bold', color: 'red', padding: 20, backgroundColor: "#F0F0F0", margin: 5  }}>
        Текст со стилями
      </text>

      {/* Внутри текстового блока могут быть только текстовые блоки. Остальные он просто проигнорирует */}
      <text class="section">
        Текст со <b>стилями</b> 
        <image src={{ url: "https://fs.chatium.io/fileservice/file/thumbnail/h/image_FzzUrqi1Vk.1920x1080.jpeg/s/600x"}}/> 
      </text>

    </screen>
  )
})
