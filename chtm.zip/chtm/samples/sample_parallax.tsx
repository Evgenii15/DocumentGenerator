import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="">
      <text class={'section'} style={{ fontSize: 'lg' }}>
        Пример параллакса
      </text>
      <parallax
        background={{
          src: {
            url: `https://picsum.photos/seed/chatium-image-10/800/1200`,
            width: 800,
            height: 1200,
          },
        }}
      />

      <sticky>
        <text style={{ padding: [20, 10], backgroundColor: 'white' }}>Это текст между параллаксами, который стики</text>
      </sticky>

      <text class={'section'} style={{ fontSize: 'lg' }}>
        Текст между параллакс-блоками
      </text>

      <parallax
        background={
          <image src={{ url: `https://picsum.photos/seed/chatium-image-11/800/1200`, width: 800, height: 1200 }} />
        }
        content={
          <text style={{ fontSize: 'xl', backgroundColor: 'rgba(0,0,0,0.3)', color: '#fff' }}>
            Это контент параллакса
          </text>
        }
      />

      <parallax
        background={
          <image src={{ url: `https://picsum.photos/seed/chatium-image-12/800/1200`, width: 800, height: 1200 }} />
        }
        contentStyle={{ justifyContent: 'center' }}
      >
        <text style={{ fontSize: 'xl', backgroundColor: 'rgba(0,0,0,0.3)', color: '#fff' }}>
          Это контент параллакса по центру
        </text>
      </parallax>

      <parallax
        content={
          <text style={{ fontSize: 'xl', backgroundColor: 'rgba(0,0,0,0.3)', color: '#fff' }}>
            Это параллакс только с контентом, без фона
          </text>
        }
        contentStyle={{ justifyContent: 'center' }}
      />

      <parallax
        background={
          <image src={{ url: `https://picsum.photos/seed/chatium-image-12/800/200`, width: 800, height: 200 }} />
        }
        content={
          <text style={{ fontSize: 'xl', backgroundColor: 'rgba(0,0,0,0.3)', color: '#fff', height: '100%' }}>
            Это параллакс, {'\n\n'}у которго фон{'\n'} меньше чем контент
          </text>
        }
        contentStyle={{ justifyContent: 'flex-start' }}
      />

      <parallax
        background={{
          src: { url: `https://picsum.photos/seed/chatium-image-11/800/800`, width: 800, height: 800 },
        }}
        style={{
          marginVertical: 15,
        }}
        contentStyle={{
          flexDirection: 'row',
          alignItems: 'flex-end',
          padding: [50, 10],
          border: [5, 'solid', 'red'],
          backgroundColor: 'rgba(0,0,0,0.2)',
        }}
        onClick={ctx.account.url('/s/dev/chatium-json/header/parallaxHeader')}
      >
        <text style={{ color: '#fff', flex: 2 }}>
          style={'\n'}
          {'    '}marginVertical: 15{'\n\n'}
          contentStyle={'\n'}
          {'    '}flexDirection: row{'\n'}
          {'    '}alignItems: flexEnd{'\n'}
          {'    '}padding: [50, 10]{'\n'}
          {'    '}border: [5, solid, red]{'\n'}
          {'    '}backgroundColor: rgba(0,0,0,0.2){'\n\n'}
          onClick=url
        </text>
        <image src={{ url: 'https://picsum.photos/seed/chatium-image-1/400/400' }} style={{ flex: 1, height: '50%' }} />
      </parallax>

      <text class="section">Клик, контекст и активные стили контента</text>
      <parallax
        background={{
          src: { url: `https://picsum.photos/seed/chatium-image-10/400/400`, width: 400, height: 400 },
        }}
        contentStyle={{
          backgroundGradient: ['rgba(255,221,51,0.2)', 'rgb(255,197,51)'],
          padding: 20,
        }}
        onClick={showToast('Клик')}
        onContext={showToast('Контекст')}
      >
        <text
          style={{
            color: '#fff',
            active: {
              color: '#f50bb4',
            },
          }}
        >
          Этот текст должен менять цвет при клике по блоку
        </text>
      </parallax>

      <text class="section" style={{ height: 1000 }}>
        Это текст под параллаксом
      </text>

    </screen>
  )
})
