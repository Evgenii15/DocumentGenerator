
/**
 * This is sample of screen with text
 * Click "Preview" to see the code result in right preview window
 * or scan QR-code with Chatium app to see native screen
 */
 app.screen('/', function (ctx, req) {
  return ( 
    <screen title="Hello world!">
      {/* section made a margins */}
      <text class="section">
        Browser and App load screen by url you can see above.
        Any screen in application it's just an URL, any transition is link to other screen
        Application shows it native not in webview. Smooth and fast
      </text>

      <text class="section" color="red" size={20}>this is why we not support HTML</text>

      <text class="section">
        All supported tags you can see here: 
      </text>
      
      <section>
        {/* This is button */}
        <button class="primary" onClick={ctx.account.navigate('https://docs.chatium.com')}>
          Documentation
        </button>
      </section>
    </screen>
  )
})
