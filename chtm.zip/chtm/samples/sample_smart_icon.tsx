import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="">
      <Example title={ctx.t('Бейджики у круглой иконки с кликом')}>
        <text style={s.exampleDesc}>
          badges=[{'\n'}
          {'  '}badge=12 position=top-right,{'\n'}
          {'  '}name=[fase, pray] class=circle style=(color/bgColor),{'\n'}]
        </text>
        <IconAllSizes
          smartIconProps={{
            name: ['fas', 'user-alt'],
            class: 'circle',
            style: {
              backgroundGradient: [-45, 'rgba(255,221,51,0.2)', 'rgb(255,197,51)'],
              borderWidth: 1,
              color: 'green',
            },
            badges: [
              {
                badge: 12,
                position: 'top-right',
              },
              {
                name: ['fas', 'pray'],
                class: 'circle',
                style: {
                  color: '#fff',
                  backgroundColor: '#999902',
                },
              },
            ],
            onClick: showToast('Клик по умной иконке'),
          }}
        />
      </Example>
      <Example title={ctx.t('Бейджики у квадратной иконки с правым кликом')}>
        <text style={s.exampleDesc}>
          badges=[{'\n'}
          {'  '}badge=1 position=top-right style=(bgColor),{'\n'}
          {'  '}badge=9999 position=custom style=(left=-10 opacity=0.9),{'\n'}
          {'  '}url=IMAGE_URL class=circle style=(border),{'\n'}]
        </text>
        <IconAllSizes
          smartIconProps={{
            name: ['fas', 'bars'],
            class: 'square',
            style: {
              backgroundGradient: ['orange', 'green'],
              borderWidth: 2,
              color: 'white',
            },
            badges: [
              {
                badge: 1,
                position: 'top-right',
                style: {
                  backgroundColor: 'rgba(109,109,109,0.5)',
                },
              },
              {
                badge: 9999,
                position: 'custom',
                style: {
                  left: -10,
                  opacity: 0.9,
                },
              },
              {
                url: IMAGE_URL,
                class: 'circle',
                style: {
                  border: [2, 'dotted', '#6215d2'],
                },
              },
            ],
            onContext: showToast('Правый клик/долгий тап по умной иконке'),
          }}
        />
      </Example>
      <Example title={ctx.t('Спиннеры')}>
        <box style={{ flexDirection: 'row', justifyContent: 'space-evenly', alignItems: 'center' }}>
          <smart-icon
            style={{
              backgroundGradient: ['rgba(255,221,51,0.2)', 'rgb(255,197,51)'],
              color: 'green',
              borderWidth: 3,
              padding: 5,
            }}
            class={'square'}
            name={['spinner', 'grid']}
          />
          <smart-icon
            style={{
              backgroundGradient: ['rgba(255,221,51,0.2)', 'rgb(255,197,51)'],
            }}
            size={'lg'}
            class={'circle'}
            name={'user'}
            badges={{
              name: ['spinner', 'pulse'],
              style: { color: 'red' },
            }}
          />
        </box>
      </Example>
      <Example title={ctx.t('Текст')}>
        <text style={s.exampleDesc}>text=A</text>
        <IconAllSizes smartIconProps={{ text: 'A' }} />

        <text style={s.exampleDesc}>text=AB</text>
        <IconAllSizes smartIconProps={{ text: 'AB' }} />

        <text style={s.exampleDesc}>text=ABC</text>
        <IconAllSizes smartIconProps={{ text: 'ABC' }} />

        <text style={s.exampleDesc}>text=ABCD</text>
        <IconAllSizes smartIconProps={{ text: 'ABCD' }} />

        <text style={s.exampleDesc}>text=ABCDE</text>
        <IconAllSizes smartIconProps={{ text: 'ABCDE' }} />
      </Example>

      <Example title={ctx.t('Иконка из набора')}>
        <text style={s.exampleDesc}>name=user</text>
        <IconAllSizes smartIconProps={{ name: 'user' }} />

        <text style={s.exampleDesc}>name=['fas', 'bars']</text>
        <IconAllSizes smartIconProps={{ name: ['fas', 'bars'] }} />
      </Example>

      <Example title={ctx.t('Картинка')}>
        <text style={s.exampleDesc}>url=IMAGE_URL</text>
        <IconAllSizes smartIconProps={{ url: IMAGE_URL }} />
      </Example>

      <Example title={ctx.t('Автовыбор: картинка -> иконка -> текст')}>
        <text style={s.exampleDesc}>url=IMAGE_URL, name=user, text=AB</text>
        <smart-icon url={IMAGE_URL} name={'user'} text={'AB'} size={'lg'} style={{ marginBottom: 10 }} />

        <text style={s.exampleDesc}>url='', name=user, text=AB</text>
        <smart-icon url={''} name={'user'} text={'AB'} size={'lg'} style={{ marginBottom: 10 }} />

        <text style={s.exampleDesc}>url='', name='', text=AB</text>
        <smart-icon url={''} name={''} text={'AB'} size={'lg'} />
      </Example>

      <Example title={ctx.t('Стилизация иконки')}>
        <text style={s.exampleDesc}>backgroundColor: yellow</text>
        <IconAllSizesAllVariants smartIconProps={{ style: { backgroundColor: 'yellow' } }} />

        <text style={s.exampleDesc}>+color: blue</text>
        <IconAllSizesAllVariants smartIconProps={{ style: { backgroundColor: 'yellow', color: 'blue' } }} />

        <text style={s.exampleDesc}>+borderWidth: 2 (цвет границы = цвету иконки)</text>
        <IconAllSizesAllVariants
          smartIconProps={{ style: { backgroundColor: 'yellow', color: 'blue', borderWidth: 2 } }}
        />

        <text style={s.exampleDesc}>+borderColor: red</text>
        <IconAllSizesAllVariants
          smartIconProps={{ style: { backgroundColor: 'yellow', color: 'blue', borderWidth: 2, borderColor: 'red' } }}
        />

        <text style={s.exampleDesc}>+padding: 5</text>
        <IconAllSizesAllVariants
          smartIconProps={{
            style: { backgroundColor: 'yellow', color: 'blue', borderWidth: 2, borderColor: 'red', padding: 5 },
          }}
        />
      </Example>
      <Example title={ctx.t('Стилизация иконки - класс circle')}>
        <text style={s.exampleDesc}>backgroundColor: rgba(255, 255, 0, 0.5), class: circle</text>
        <IconAllSizesAllVariants
          smartIconProps={{
            style: {
              backgroundColor: 'rgba(255, 255, 0, 0.5)',
            },
            class: ['circle'],
          }}
        />
        <text style={s.exampleDesc}>+border: [2, "solid", red]</text>
        <IconAllSizesAllVariants
          smartIconProps={{
            style: {
              backgroundColor: 'rgba(255, 255, 0, 0.5)',
              border: [2, 'solid', 'red'],
            },
            class: ['circle'],
          }}
        />
        <text style={s.exampleDesc}>+border: [2, "dotted", red]</text>
        <IconAllSizesAllVariants
          smartIconProps={{
            style: {
              backgroundColor: 'rgba(255, 255, 0, 0.5)',
              border: [2, 'dotted', 'red'],
            },
            class: ['circle'],
          }}
        />
      </Example>
      <Example title={ctx.t('Стилизация иконки - класс square')}>
        <text style={s.exampleDesc}>backgroundColor: rgba(255, 255, 0, 0.5), class: square</text>
        <IconAllSizesAllVariants
          smartIconProps={{
            style: {
              backgroundColor: 'rgba(255, 255, 0, 0.5)',
            },
            class: ['square'],
          }}
        />
        <text style={s.exampleDesc}>+border: [2, "solid", red]</text>
        <IconAllSizesAllVariants
          smartIconProps={{
            style: {
              backgroundColor: 'rgba(255, 255, 0, 0.5)',
              border: [2, 'solid', 'red'],
            },
            class: ['square'],
          }}
        />
      </Example>

      <Example title={ctx.t('Стилизация иконки - градиентный фон')}>
        <text style={s.exampleDesc}>colors: ['rgba(255,221,51,0.2)', 'rgb(255,197,51)'],</text>
        <IconAllSizesAllVariants
          smartIconProps={{
            style: {
              backgroundGradient: ['rgba(255,221,51,0.2)', 'rgb(255,197,51)'],
            },
            class: ['square'],
          }}
        />
        <IconAllSizesAllVariants
          smartIconProps={{
            style: {
              backgroundGradient: ['rgba(255,221,51,0.2)', 'rgb(255,197,51)'],
            },
            class: ['circle'],
          }}
        />
      </Example>

      <Example title={ctx.t('События на иконке')}>
        <IconAllSizesAllVariants
          smartIconProps={{
            style: {
              backgroundGradient: ['rgba(255,221,51,0.2)', 'rgb(255,197,51)'],
            },
            class: ['square'],
            onClick: showToast('Вы нажали на иконку'),
            onContext: showToast('Контекст на иконке'),
          }}
        />
      </Example>

      <Example title={ctx.t('Спиннеры в смарт-иконке')}>
        <smart-icon name={['spinner', 'plane']} />
        <smart-icon name={['spinner', 'chase']} />
        <smart-icon name={['spinner', 'bounce']} />
        <smart-icon name={['spinner', 'wave']} />
        <smart-icon name={['spinner', 'pulse']} />
        <smart-icon name={['spinner', 'flow']} />
        <smart-icon name={['spinner', 'swing']} />
        <smart-icon name={['spinner', 'circle']} />
        <smart-icon name={['spinner', 'circle-fade']} />
        <smart-icon name={['spinner', 'grid']} />
        <smart-icon name={['spinner', 'fold']} />
        <smart-icon name={['spinner', 'wander']} />
      </Example>

      <Example title={ctx.t('Системные смарт-иконки')}>
        <smart-icon name={['system', 'android-back']} />
        <smart-icon name={['system', 'dots']} />
        <smart-icon name={['system', 'ios-back']} />
        <smart-icon name={['system', 'pause']} />
        <smart-icon name={['system', 'play-arrow']} />
        <smart-icon name={['system', 'replay']} />
        <smart-icon name={['system', 'fast-forward-10']} />
        <smart-icon name={['system', 'rewind-10']} />
      </Example>

    </screen>
  )
})




const s = {
  exampleRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    paddingVertical: 5,
    borderStyle: 'dashed',
    borderBottom: [1, '#aaa'],
  },
  exampleDesc: {
    fontSize: 'sm' as const,
  },
  lastRow: {
    borderBottomWidth: 0,
  },
  examplePair: {
    alignItems: 'center',
    paddingVertical: 5,
    borderBottom: [1, '#aaa'],
  },
}

function Example({ title }: any, ...children: any[]) {
  return (
    <>
      <text style={{ fontSize: 'md', fontWeight: '600', paddingHorizontal: 10 }}>{title}</text>
      <box style={{ backgroundColor: '#f0f0f0', padding: 10, marginBottom: 15 }}>{children}</box>
    </>
  )
}


function IconAllSizes({ smartIconProps }: any) {
  return (
    <box
      style={{
        flexDirection: 'row',
        flexWrap: 'wrap',
        margin: -5,
        marginBottom: 10,
      }}
    >
      {['sm' as const, 'md' as const, 'lg' as const, 'xl' as const, '2xl' as const, 15, 25].map(size => (
        <box style={{ padding: 10, margin: 5, backgroundColor: '#ddd', justifyContent: 'center' }}>
          <smart-icon {...smartIconProps} size={size} />
          <text style={{ textAlign: 'center', fontSize: 'sm' }}>{size}</text>
        </box>
      ))}
    </box>
  )
}

function IconAllSizesAllVariants({ smartIconProps }: IconAllSizesProps) {
  return (
    <box
      style={{
        backgroundColor: '#eee',
        borderBottom: [1, '#aaa'],
        marginBottom: 10,
      }}
    >
      <IconAllSizes smartIconProps={{ ...smartIconProps, text: 'AB' }} />
      <IconAllSizes smartIconProps={{ ...smartIconProps, name: 'user' }} />
      <IconAllSizes smartIconProps={{ ...smartIconProps, url: IMAGE_URL }} />
    </box>
  )
}

const IMAGE_URL = 'https://cdn.pixabay.com/photo/2020/05/15/18/46/corona-5174671_1280.jpg'
