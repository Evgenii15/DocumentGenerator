app.screen('/', function (ctx, req) {
  return (
    <screen title="Основы верстки">
      <box style={{padding: 10, margin: 10, border: [ 1, 'stroke', '#999'], borderRadius: 15 }}>
        <text>Основа верстки &lt;box&gt; - это просто некий контейнер, как div в html</text>
      </box>

      <box style={{flexDirection: 'row'}}>
        <box class='section' style={{ flex: 1 }}>
          <text>Box поддерживает flex</text>
          <text>И может быть вложенным в другой box</text>
        </box>
        <box class='section' style={{flex:1}}>
          <button class='primary'>Нажми меня</button>
          <text>За счет этого можно располагать блоки как угодно</text>
        </box>
      </box>
    </screen>
  )
})
