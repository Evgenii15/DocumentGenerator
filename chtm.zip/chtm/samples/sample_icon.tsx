import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="">
      <Example title={ctx.t('Размер')}>
        <box style={s.exampleRow}>
          <icon name="user" size="sm" />
          <text text="size=sm" />
        </box>
        <box style={s.exampleRow}>
          <icon name="user" size="md" />
          <text text={ctx.t('size=md (по-умолчанию)')} />
        </box>
        <box style={s.exampleRow}>
          <icon name="user" size="lg" />
          <text text="size=lg" />
        </box>
        <box style={s.exampleRow}>
          <icon name="user" size="xl" />
          <text text="size=xl" />
        </box>
        <box style={s.exampleRow}>
          <icon name="user" size="2xl" />
          <text text="size=2xl" />
        </box>
        <box style={[s.exampleRow, { borderBottomWidth: 0 }]}>
          <icon name="user" size={15} />
          <text text={ctx.t('size=15 (любой размер в пикселях)')} />
        </box>
      </Example>

      <Example title={ctx.t('Цвета и границы')}>
        <box style={s.exampleRow}>
          <icon name={['fas', 'bars']} size="sm" style={{ color: 'green' }} />
          <text>color=green</text>
        </box>
        <box style={s.exampleRow}>
          <icon name={['fas', 'bars']} size="sm" style={{ color: 'green', backgroundColor: 'orange' }} />
          <text>+backgroundColor=orange</text>
        </box>
        <box style={s.exampleRow}>
          <icon name={['fas', 'bars']} size="sm" style={{ color: 'green', backgroundColor: 'orange', padding: 3 }} />
          <text>+padding=3</text>
        </box>
        <box style={s.exampleRow}>
          <icon
            name={['fas', 'bars']}
            size="sm"
            style={{ color: 'green', backgroundColor: 'orange', padding: 3, borderWidth: 2 }}
          />
          <text style={{ textAlign: 'right', marginLeft: 10, flex: -1 }}>
            +borderWidth=2{'\n'}(цвет границы по умолчанию соответствует цвету иконки)
          </text>
        </box>
        <box style={s.exampleRow}>
          <icon
            name={['fas', 'bars']}
            size="sm"
            style={{
              color: 'green',
              backgroundColor: 'orange',
              padding: 3,
              borderWidth: 2,
              borderRightColor: 'magenta',
            }}
          />
          <text style={{ textAlign: 'right', marginLeft: 10, flex: -1 }}>+borderRightColor=magenta</text>
        </box>
        <box style={s.exampleRow}>
          <icon
            name={['fas', 'bars']}
            size="sm"
            style={{ color: 'green', backgroundColor: 'orange', padding: 3, borderWidth: 2, borderRadius: 500 }}
          />
          <text>+borderRadius=500</text>
        </box>
        <box style={[s.exampleRow, { borderBottomWidth: 0 }]}>
          <icon
            name={['fas', 'bars']}
            size="sm"
            style={{
              color: 'green',
              backgroundColor: 'orange',
              padding: 3,
              borderWidth: 2,
              borderRadius: 500,
              borderColor: 'magenta',
            }}
          />
          <text>+borderColor=magenta</text>
        </box>
      </Example>
      <Example title={ctx.t('Позиционирование и события')}>
        <box style={s.examplePair}>
          <text style={{ textAlign: 'center' }}>alignSelf=flex-end, marginTop: 20 onClick=showToast</text>
          <icon
            name={['fas', 'heartbeat']}
            style={{ alignSelf: 'flex-end', marginTop: 20 }}
            onClick={showToast(ctx.t('Вы кликнули по иконке'))}
          />
        </box>
        <box style={[s.examplePair, { height: 120 }]}>
          <text style={{ textAlign: 'center' }}>position: absolute, left=120, bottom=10%, onContext=showToast</text>
          <icon
            name={['fas', 'heartbeat']}
            style={{ position: 'absolute', left: 120, bottom: '10%' }}
            onContext={showToast(ctx.t('Правый клик/длинный тап по иконке'))}
          />
        </box>
        <box style={[s.examplePair, { borderBottomWidth: 0 }]}>
          <text style={{ textAlign: 'center' }}>active.opacity=0.5, active.color=red, onClick=showToast</text>
          <icon
            name={['fas', 'heartbeat']}
            style={{
              color: 'green',
              backgroundColor: 'orange',
              padding: 5,
              borderWidth: 2,
              borderRadius: 500,
              active: { backgroundColor: 'red', opacity: 0.5 },
            }}
            onClick={showToast(ctx.t('Клик по иконке с анимацией'))}
          />
        </box>
      </Example>

      <Example title={ctx.t('Спиннеры')}>
        <box style={{ flexDirection: 'row', flexWrap: 'wrap', margin: -10 }}>
          <Spinner name="plane" />
          <Spinner name="chase" />
          <Spinner name="bounce" />
          <Spinner name="wave" />
          <Spinner name="pulse" />
          <Spinner name="flow" style={{ color: 'blue' }} />
          <Spinner name="swing" />
          <Spinner name="circle" />
          <Spinner name="circle-fade" />
          <Spinner name="grid" />
          <Spinner name="fold" />
          <Spinner name="wander" style={{ borderRadius: 15 }} />
        </box>
      </Example>

      <Example title={ctx.t('Системные иконки')}>
        <box style={{ flexDirection: 'row', flexWrap: 'wrap', margin: -10 }}>
          <SystemIcon name={'android-back'} />
          <SystemIcon name={'dots'} />
          <SystemIcon name={'ios-back'} />
          <SystemIcon name={'pause'} />
          <SystemIcon name={'play-arrow'} />
          <SystemIcon name={'replay'} />
          <SystemIcon name={'fast-forward-10'} />
          <SystemIcon name={'rewind-10'} />
        </box>
      </Example>
    </screen>
  )
})


const s = {
  exampleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 5,
    borderStyle: 'dashed',
    borderBottom: [1, '#aaa'],
  },
  examplePair: {
    alignItems: 'center',
    paddingVertical: 5,
    borderBottom: [1, '#aaa'],
  },
}


function Example({ title, containerStyle }, ...children) {
  return (
    <>
      <text style={{ fontSize: 'md', fontWeight: '600', paddingHorizontal: 10 }}>{title}</text>
      <box style={{ backgroundColor: '#ddd', padding: 10, marginBottom: 15, ...containerStyle }}>{children}</box>
    </>
  )
}

interface SpinnerProps {
  name: string
  style?: object
}

function Spinner({ name, style }: SpinnerProps) {
  return (
    <box>
      <icon
        name={['spinner', name]}
        size="lg"
        style={{
          color: 'green',
          backgroundColor: 'orange',
          padding: 3,
          borderWidth: 2,
          borderRadius: 500,
          margin: 10,
          ...style,
        }}
      />
      <text style={{ textAlign: 'center' }}>{name}</text>
    </box>
  )
}


function SystemIcon({ name, style }) {
  return (
    <box style={{ alignItems: 'center' }}>
      <icon
        name={['system', name]}
        size="lg"
        style={{
          color: 'green',
          backgroundColor: 'orange',
          padding: 3,
          borderWidth: 2,
          borderRadius: 500,
          margin: 10,
          ...style,
        }}
      />
      <text style={{ textAlign: 'center' }}>{name}</text>
    </box>
  )
}