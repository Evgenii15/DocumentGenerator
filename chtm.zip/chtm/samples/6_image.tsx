import {ImageBlock as Image1} from './sample.jpg'
import { getThumbnailUrl} from '@chatium/storage'
import {showToast} from '@chatium/json'

app.screen('/', function (ctx, req) {
  return (
    <screen title="Примеры картинок">
      <text style={titleStyle}>Просто добавленные картинки разных размеров</text>
      <text>
        По умолчанию картинка занимает столько места сколько она должна занимать. Если она больше ширины экрана или
        блока в который она вложена - она ограничивается шириной экрана или блока.{'\n\n'}
        Размеры задаются в логических пикселях, а не в "физических" пикселях устройства. Поэтому, чтобы хорошо показать
        картинку размером 100x50 на iPhone, размер исходника должен быть 3x, то есть 300x150.
      </text>
      <SizedImage width={100} height={50} noMargins />
      <SizedImage width={200} height={100} onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')} />
      <SizedImage width={300} height={150} inlineTitle />
      <SizedImage width={600} height={300} inlineTitle />
      <SizedImage width={1200} height={600} inlineTitle />

      <text style={titleStyle}>Заданные размеры исходника</text>
      <text>
        Если задавать явно src.width/height, то можно вручную изменить:{'\n'}
        1) Соотношение сторон изображения{'\n'}
        2) Место, занимаемое изображением по-умолчанию, если не заданы явные style.width/height{'\n\n'}
        Явно заданные размеры исходника помогают в некоторых случаях предотвратить "прыгания" экрана при подгрузке
        картинки, а также ускоряют рендеринг экрана в мобильном приложении.
      </text>
      <SizedImage width={600} height={300} srcWidth={125} srcHeight={125} noMargins />
      <SizedImage width={600} height={300} srcWidth={600} srcHeight={400} noMargins inlineTitle />
      <SizedImage width={600} height={300} srcWidth={300} srcHeight={300} imageStyle={{ height: 150 }} noMargins />
      <SizedImage
        width={600}
        height={300}
        srcWidth={400}
        srcHeight={400}
        imageStyle={{ width: 250 }}
        onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        noMargins
      />

      <text style={titleStyle}>Явные размеры (style.width/height)</text>
      <SizedImage width={2400} height={1200} imageStyle={{ width: '70%' }} noMargins inlineTitle />
      <SizedImage width={2400} height={1200} imageStyle={{ width: '150%' }} inlineTitle />
      <SizedImage width={2400} height={1200} imageStyle={{ width: 900 }} inlineTitle />
      <SizedImage width={2400} height={1200} imageStyle={{ width: 900, maxWidth: '100%' }} inlineTitle />
      <SizedImage width={2400} height={1200} imageStyle={{ width: 200, height: 200 }} inlineTitle />
      <SizedImage
        width={2400}
        height={1200}
        imageStyle={{ height: 100 }}
        onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        inlineTitle
      />
      <SizedImage width={2400} height={1200} imageStyle={{ height: 300 }} inlineTitle />
      <SizedImage width={200} height={100} imageStyle={{ width: 200, height: 200 }} inlineTitle />

      <text style={titleStyle}>Масштабирование картинки (resizeMode)</text>
      <SizedImage
        width={2400}
        height={1200}
        imageStyle={{ width: 200, height: 200 }}
        resizeMode={'cover'}
        inlineTitle
      />
      <SizedImage
        width={2400}
        height={1200}
        imageStyle={{ width: 300, height: 300, border: [1, 'solid', '#000'] }}
        resizeMode={'contain'}
        onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        inlineTitle
      />
      <SizedImage
        width={2400}
        height={1200}
        imageStyle={{ width: 200, height: 200 }}
        resizeMode={'stretch'}
        inlineTitle
      />

      <text style={titleStyle}>Граница и радиус</text>
      <SizedImage
        width={600}
        height={600}
        imageStyle={{ width: 200, height: 200, border: [4, 'solid', 'green'], borderRadius: 333 }}
        resizeMode={'cover'}
      />

      <text style={titleStyle}>Картинки в боксе с отступами</text>
      <box style={{ paddingHorizontal: 20, paddingVertical: 10, marginBottom: 10, backgroundColor: '#cfa311' }}>
        <SizedImage width={200} height={100} />
        <SizedImage width={2400} height={1200} inlineTitle />
      </box>

      <text style={titleStyle}>Картинки в боксе с флексом</text>
      <text>flexDirection: row</text>
      <box
        style={{
          paddingHorizontal: 10,
          paddingVertical: 10,
          marginBottom: 10,
          backgroundColor: '#cfa311',
          flexDirection: 'row',
          alignItems: 'flex-start',
        }}
      >
        <SizedImage inlineTitle noMargins width={100} height={50} />
        <SizedImage
          inlineTitle
          noMargins
          width={133}
          height={67}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <SizedImage inlineTitle noMargins width={167} height={83} />
        <SizedImage inlineTitle noMargins width={200} height={100} />
      </box>
      <text>flexDirection: row, flexWrap: wrap</text>
      <box
        style={{
          paddingHorizontal: 10,
          paddingVertical: 10,
          marginBottom: 10,
          backgroundColor: '#cfa311',
          flexDirection: 'row',
          flexWrap: 'wrap',
          alignItems: 'flex-start',
        }}
      >
        <SizedImage
          inlineTitle
          noMargins
          width={150}
          height={75}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <SizedImage inlineTitle noMargins width={200} height={100} />
        <SizedImage inlineTitle noMargins width={250} height={125} />
        <SizedImage inlineTitle noMargins width={300} height={150} />
        <SizedImage inlineTitle noMargins width={1200} height={600} />
      </box>

      <text style={titleStyle}>Плитка из картинок</text>
      <box
        style={{
          flexDirection: 'row',
          flexWrap: 'wrap',
        }}
      >
        <image src={{ url: getImageUrl(0, 600, 600) }} style={{ width: '33.33333%' }} />
        <image
          src={{ url: getImageUrl(1, 600, 600) }}
          style={{ width: '33.33333%' }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <image src={{ url: getImageUrl(2, 600, 600) }} style={{ width: '33.33333%' }} />
        <image src={{ url: getImageUrl(6, 600, 600) }} style={{ width: '33.33333%' }} />
        <image src={{ url: getImageUrl(7, 600, 600) }} style={{ width: '33.33333%' }} />
        <image src={{ url: getImageUrl(8, 600, 600) }} style={{ width: '33.33333%' }} />
        <image src={{ url: getImageUrl(9, 600, 600) }} style={{ width: '33.33333%' }} />
      </box>

      <text style={titleStyle}>Плитка из картинок, устанавливаем flexBasis = 33.333333%</text>
      <box
        style={{
          flexDirection: 'row',
          flexWrap: 'wrap',
        }}
      >
        <image src={{ url: getImageUrl(0, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
        <image
          src={{ url: getImageUrl(1, 600, 600) }}
          style={{ flexBasis: '33.33333%' }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <image src={{ url: getImageUrl(2, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(6, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(7, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(8, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(9, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
      </box>

      <text style={titleStyle}>
        Плитка из картинок, картинки прямоугольные, но искуственно заставляем рисовать квадратные
      </text>
      <box
        style={{
          flexDirection: 'row',
          flexWrap: 'wrap',
        }}
      >
        <image src={{ url: getImageUrl(0, 1200, 600), width: 600, height: 600 }} style={{ flexBasis: '33.33333%' }} />
        <image
          src={{ url: getImageUrl(1, 1200, 600), width: 600, height: 600 }}
          style={{ flexBasis: '33.33333%' }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <image src={{ url: getImageUrl(2, 1200, 600), width: 600, height: 600 }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(6, 1200, 600), width: 600, height: 600 }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(7, 1200, 600), width: 600, height: 600 }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(8, 1200, 600), width: 600, height: 600 }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(9, 1200, 600), width: 600, height: 600 }} style={{ flexBasis: '33.33333%' }} />
      </box>

      <text style={titleStyle}>
        Вертикальная Плитка из картинок, картинки прямоугольные, но искуственно заставляем рисовать квадратные.
      </text>
      <box
        style={{
          flexDirection: 'column',
          flexWrap: 'wrap',
          height: 400,
        }}
      >
        <image src={{ url: getImageUrl(0, 600, 600), width: 600, height: 600 }} style={{ height: '33.33333%' }} />
        <image
          src={{ url: getImageUrl(1, 1000, 600), width: 600, height: 600 }}
          style={{ height: '33.33333%' }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <image src={{ url: getImageUrl(2, 1500, 500), width: 600, height: 600 }} style={{ height: '33.33333%' }} />
        <image src={{ url: getImageUrl(6, 1200, 600), width: 600, height: 600 }} style={{ height: '33.33333%' }} />
        <image src={{ url: getImageUrl(7, 1200, 600), width: 600, height: 600 }} style={{ height: '33.33333%' }} />
      </box>

      <text style={titleStyle}>
        Вертикальная Плитка из картинок с flexBasis=33.33333%, картинки квадратные, но размеры исходника не заданы.
      </text>
      <box
        style={{
          flexDirection: 'column',
          flexWrap: 'wrap',
          height: 400,
        }}
      >
        <image src={{ url: getImageUrl(0, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
        <image
          src={{ url: getImageUrl(1, 600, 600) }}
          style={{ flexBasis: '33.33333%' }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <image src={{ url: getImageUrl(2, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(6, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
        <image src={{ url: getImageUrl(7, 600, 600) }} style={{ flexBasis: '33.33333%' }} />
      </box>

      <text style={titleStyle}>align-self у картинки</text>
      <image src={{ url: getImageUrl(0, 200, 200) }} style={{ alignSelf: 'flex-start' }} />
      <image
        src={{ url: getImageUrl(0, 200, 200) }}
        style={{ alignSelf: 'center' }}
        onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
      />
      <image src={{ url: getImageUrl(0, 200, 200) }} style={{ alignSelf: 'flex-end' }} />
      <box style={{ paddingVertical: 10, backgroundColor: '#dec585', flexDirection: 'row' }}>
        <image src={{ url: getImageUrl(1, 600, 600) }} style={{ height: 100, alignSelf: 'flex-start' }} />
        <image
          src={{ url: getImageUrl(1, 600, 600) }}
          style={{ height: 120, alignSelf: 'center' }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <image src={{ url: getImageUrl(1, 600, 600) }} style={{ height: 110, alignSelf: 'flex-end' }} />
        <image src={{ url: getImageUrl(1, 600, 600) }} style={{ height: 130, alignSelf: 'center' }} />
      </box>

      <text style={titleStyle}>Полупрозрачная картинка и фоны</text>
      <box style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        <image
          src={{ url: 'https://cdn.pixabay.com/photo/2019/09/19/12/23/bird-4489182_1280.png' }}
          style={{ width: '30%' }}
        />
        <image
          src={{ url: 'https://cdn.pixabay.com/photo/2019/09/19/12/23/bird-4489182_1280.png' }}
          style={{ width: '30%', backgroundColor: 'red' }}
        />
        <image
          src={{ url: 'https://cdn.pixabay.com/photo/2019/09/19/12/23/bird-4489182_1280.png' }}
          style={{ width: '30%', backgroundGradient: [45, 'red', 'pink'] }}
        />
      </box>

      <text style={titleStyle}>События</text>
      <box style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        <image
          src={{ url: 'https://cdn.pixabay.com/photo/2019/09/19/12/23/bird-4489182_1280.png' }}
          style={{ width: '30%' }}
          onClick={showToast('Вы нажали на картинку')}
          onContext={showToast('Контекст на картинке')}
        />
        <image
          src={{ url: 'https://cdn.pixabay.com/photo/2019/09/19/12/23/bird-4489182_1280.png' }}
          style={{
            width: '30%',
            active: {
              backgroundColor: 'red',
            },
          }}
          onClick={showToast('Вы нажали на картинку')}
          onContext={showToast('Контекст на картинке')}
        />
      </box>

      <text style={titleStyle}>Эластичные (flexible) картинки</text>
      <text>
        По-умолчанию картинка не-эластичная в том смысле, что она старается сохранить соотношение сторон, если задано
        только одно из измерений.{'\n'}
        Если же сделать картинку эластичной, то есть задать ей что либо из style.flex/flexGrow/flexShrink отличным от
        нуля, то соотношение сторон сохраняется, только если НЕ задано измерение, перпендикулярное flex-оси (для
        flexDirection=row(-reverse) - height, для column(-reverse) - width.{'\n\n'}В примере показаны две одинаковые
        картинки с размерами исходника 150x150. У первой стоит flex: 1, у второй - flex: 0 (поведение по-умолчанию).
        Первая картинка заняла всё доступное пространство, сохранив соотношение сторон, вторая осталась в оригинальном
        размере.
      </text>
      <box
        style={{
          flexDirection: 'row',
          alignItems: 'center',
        }}
      >
        <image src={flexImageSrc} style={{ flex: 1 }} />
        <image src={flexImageSrc} style={{ flex: 0 }} onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')} />
      </box>

      <text>
        Теперь второй картинке добавляем явную высоту height: 100. Она уменьшилась, но соотношение сохранилось.
      </text>
      <box
        style={{
          flexDirection: 'row',
          alignItems: 'center',
        }}
      >
        <image src={flexImageSrc} style={{ flex: 1 }} />
        <image
          src={flexImageSrc}
          style={{ flex: 0, height: 100 }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
      </box>

      <text>
        Добавляем второй картинке ещё и flex: 1. Теперь она эластичная, и ширина определяется flex-свойствами, но
        поскольку у неё явно задана высота, оригинально соотношение сторон не сохраняется.
      </text>
      <box
        style={{
          flexDirection: 'row',
          alignItems: 'center',
        }}
      >
        <image src={flexImageSrc} style={{ flex: 1 }} />
        <image
          src={flexImageSrc}
          style={{ flex: 1, height: 100 }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
      </box>

      <text>
        Теперь то же самое, но для flexDirection: column-reverse (вторая картинка сверху, у неё width: 100, flex: 1).
      </text>
      <box
        style={{
          flexDirection: 'column-reverse',
          alignItems: 'center',
          height: 400,
        }}
      >
        <image src={flexImageSrc} style={{ flex: 1 }} />
        <image
          src={flexImageSrc}
          style={{ flex: 1, width: 100 }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
      </box>

      <text>Теперь то же самое, но без заданных размеров исходника. Исходные картинки 300x300</text>
      <box
        style={{
          flexDirection: 'column-reverse',
          alignItems: 'center',
          height: 400,
        }}
      >
        <image src={{ url: getImageUrl(0, 300, 300) }} style={{ flex: 1 }} />
        <image
          src={{ url: getImageUrl(0, 300, 300) }}
          style={{ flex: 1, width: 100 }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
      </box>

      <text>Без заданных размеров исходника для горизонтали</text>
      <box
        style={{
          flexDirection: 'row',
          alignItems: 'center',
        }}
      >
        <image src={{ url: getImageUrl(0, 300, 300) }} style={{ flex: 1 }} />
        <image
          src={{ url: getImageUrl(0, 300, 300) }}
          style={{ flex: 1, height: 100 }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
      </box>

      <text style={titleStyle}>Горизонтальный флекс (тестовый кейс для Артура).</text>
      <text>
        flexDir=row при flexShrink=1 если у картинки задана высота, она схлопывается в ноль. Вероятно в этом случае ей
        нужно выставить явно width=[размер относительно заданного height с сохранением пропорций]
      </text>
      <box style={{ flexDirection: 'row', height: 200, backgroundColor: 'yellow' }}>
        <image
          src={{ url: getImageUrl(0, 150, 150), width: 100, height: 100 }}
          style={{ flexShrink: 1, height: '50%' }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <image src={{ url: getImageUrl(1, 150, 150) }} style={{ flexShrink: 1, height: '50%' }} />
        <image src={{ url: getImageUrl(2, 150, 150) }} style={{ height: '50%' }} />
        <image src={{ url: getImageUrl(6, 150, 150) }} style={{ flexShrink: 1 }} />
      </box>

      <text style={titleStyle}>Вертикальный флекс (тестовый кейс для Артура).</text>
      <text>
        Тестовый кейс для Артура. flexDir=column при flexShrink=1 если у картинки задана ширина, она схлопывается в
        ноль. Вероятно в этом случае ей нужно выставить явно height=[размер относительно заданного width с сохранением
        пропорций]
      </text>
      <box
        style={{
          flexDirection: 'column',
          height: 400,
        }}
      >
        <image
          src={{ url: getImageUrl(0, 150, 150), width: 100, height: 100 }}
          style={{ flexShrink: 1, width: '33%' }}
          onClick={ctx.account.url('/s/dev/chatium-json/blocks/button')}
        />
        <image src={{ url: getImageUrl(1, 150, 150) }} style={{ flexShrink: 1, width: '33%' }} />
        <image src={{ url: getImageUrl(2, 150, 150) }} style={{ width: '33%' }} />
        <image src={{ url: getImageUrl(6, 150, 150) }} style={{ flexShrink: 1 }} />
      </box>

    </screen>
  )
})




interface SizedImageProps {
  width: number
  height: number
  imageStyle?: ImageProps['style']
  noMargins?: boolean
  unknownSize?: boolean
  inlineTitle?: boolean
  imageIndex?: number
  srcWidth?: number
  srcHeight?: number
  resizeMode?: ImageProps['resizeMode']
  onClick?: ChatiumActions | string
}

export function SizedImage({
  inlineTitle,
  width,
  height,
  imageStyle,
  noMargins,
  imageIndex,
  srcWidth,
  srcHeight,
  resizeMode,
  onClick,
}: SizedImageProps) {
  const titlePosition = inlineTitle ? 'inline' : 'right'
  const source: ImageProps['src'] = {
    url: getImageUrl(imageIndex ?? 0, width, height),
  }
  if (srcWidth) {
    source.width = srcWidth
  }
  if (srcHeight) {
    source.height = srcHeight
  }
  return (
    <box style={{ marginTop: noMargins ? 0 : 20, alignItems: 'center', flexDirection: 'row', alignSelf: 'flex-start' }}>
      <image src={source} style={[imageStyle]} resizeMode={resizeMode} onClick={onClick} />
      <text style={[{ fontSize: 'sm' }, titlePosition === 'inline' ? inlineTitleStyle : rightTitleStyle]}>
        {width}x{height}
        {imageStyle ? `, ${JSON.stringify(imageStyle)}` : ``}
        {srcWidth || srcHeight ? `, src: ${srcWidth}x${srcHeight}` : ''}
        {resizeMode ? `, resizeMode:${resizeMode}` : ''}
      </text>
    </box>
  )
}

const titleStyle = {
  fontSize: 'lg' as const,
  fontWeight: '800' as const,
  marginTop: 20,
}

const inlineTitleStyle: TextProps.Style = {
  position: 'absolute',
  left: 0,
  top: 0,
  right: 0,
  textAlign: 'left',
  textAlignVertical: 'center',
  color: '#efefef',
  backgroundColor: 'rgba(0,0,0,0.5)',
  padding: 3,
}

const rightTitleStyle: TextProps.Style = {
  marginLeft: 10,
}

const imageSlugs = [
  'chatium-image',
  'chatium-image-1',
  'chatium-image-2',
  'chatium-image-3',
  'chatium-image-4',
  'chatium-image-5',
  'chatium-image-6',
  'chatium-image-7',
  'chatium-image-8',
  'chatium-image-9',
]

function getImageUrl(index: number, width: number, height: number) {
  return `https://picsum.photos/seed/${imageSlugs[index ?? 0]}/${width}/${height}`
}

const flexImageSrc = {
  url: getImageUrl(0, 600, 300),
  width: 150,
  height: 150,
}
