app.screen('/', function (ctx, req) {

  return (
    <screen title="Примеры кнопок">
      <section> 
        <button class="primary">primary</button>
      </section>

      {["secondary", "success", "danger", "warning", "info", "light", "dark", "link"].map( 
        cls => 
        <button class={["section", cls]}>{cls}</button>
      )}

      <button
        class={['section']}
        title="Стилизация кнопок"
        style={{
          backgroundColor: 'red',
          color: 'green',
          active: {
            backgroundColor: 'green',
            color: 'blue',
          },
        }}
      />

      <button
        class={['section', 'primary']}
        leftIcon={{
          name: 'user',
        }}
        title={'Иконка слева'}
      />
      <button
        class={['section', 'primary']}
        rightIcon={{
          name: 'user',
        }}
        title={'Иконка справа'}
      />
      <button
        class={['section', 'primary']}
        leftIcon={{
          name: 'user',
        }}
      />


      <box style={{ flexDirection: 'row', justifyContent: 'space-evenly' }}>
        <button
          class={['primary']}
          leftIcon={{
            name: 'user',
          }}
        />
        <button
          class={['primary']}
          leftIcon={{
            name: ['fas', 'apple-alt'],
          }}
        />
        <button
          class={['primary']}
          leftIcon={{
            name: ['fas', 'battery-half'],
          }}
        />
      </box>
      <box style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 10, overflow: 'visible' }}>
        <button
          class="secondary"
          leftIcon={{
            name: 'user',
          }}
          style={{
            borderTopRightRadius: 0,
            borderBottomRightRadius: 0,
            borderWidth: 'hairline',
            borderColor: '#fff',
          }}
        />
        <button
          class="primary"
          leftIcon={{
            name: ['fas', 'apple-alt'],
          }}
          style={{
            borderRadius: 0,
            borderColor: '#fff',
            borderWidth: ['hairline', 0],
          }}
        />
        <button
          class="secondary"
          leftIcon={{
            name: ['fas', 'battery-half'],
          }}
          style={{
            borderTopLeftRadius: 0,
            borderBottomLeftRadius: 0,
            borderWidth: 'hairline',
            borderColor: '#fff',
          }}
        />
      </box>


    </screen>
  )
})
