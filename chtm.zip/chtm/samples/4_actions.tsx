import {
  showToast, navigate, apiCall, showTextDialog, attachMedia , refresh, confirmPhone, copyToClipboard
} from '@chatium/json'
import { getThumbnailUrl, getDownloadUrl } from '@chatium/storage'

app.screen('/', function (ctx, req) {
  return (
    <screen title="Возможные действия">
      <button onClick={refresh()} class="section">{'Обновить: ' + (new Date().toLocaleTimeString()  ) }</button>
      <button onClick={showToast('Привет, ты нажал на кнопку')}  class="section">Просто вывести какое-то сообщение</button>
      <button onClick={ctx.router.apiCall('/hello', { value: "My name" } )} class="section">Сделать apiCall</button>
      <button 
        onClick={showTextDialog( { title: "Введите ваше имя", placeholder: "Имя", submitUrl: ctx.router.url('/hello'), submitButtonTitle: "Сказать привет" })} 
        class="section">
        Спросить имя
      </button>
      <button onClick={ctx.router.apiCall('/inc')} onContext={ctx.router.apiCall('/reset')} class="section">{'Увеличить число: ' + (ctx.router.params.number ?? 0)}</button>
      <button onClick={copyToClipboard("Значение")} class="section">Скопировать в буфер</button>
      <button onClick={confirmPhone()} class="section">Авторизовать</button>
      <button onClick={{ type: "attachMedia", title: "Приложите файл", submitUrl: ctx.router.url('/add-file')}} class="section">Отправить файл</button>
      
    </screen>
  )
})

/**
 * Говорит привет имени, которое передали в параметре value
 */
app.apiCall('/hello', function(ctx, req) {
  return showToast('Привет ' + req.body.value )
})

/**
 * Увеличивает параметр number на 1
 */
app.apiCall('/inc', async function (ctx, req) {
  let number = ctx.router.params.number;
  if ( ! number ) number = 0;
  number++;
  await ctx.router.setParam('number', number)
  return [
    refresh(),
    showToast('Чтобы сбросить - нажмите правой кнопкой')
  ];
})

/**
 * Сбрасывает параметр number в 0 
 */
app.apiCall('/reset', async function (ctx, req) {
  await ctx.router.setParam('number', 0)
  return refresh();
});


/**
 * Переадресовывает на просмотр файла (вызывается после загрузки файла)
 */
app.apiCall('/add-file', function (ctx, req) {
  return ctx.router.navigate('/file/' + req.body.file.hash)
})

app.screen('/file/:hash', function (ctx, req) {
  return <screen>
    <image src={getThumbnailUrl(req.params.hash)} />
    <button onClick={ctx.account.navigate(getDownloadUrl(req.params.hash), { openInExternalApp: true })}>Download</button>
  </screen>
})
