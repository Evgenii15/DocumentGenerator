import {showToast} from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="Box">
      <header title={ctx.t('Блоки > {type}', { type: 'box' })} rightButton={{ onClick: showToast('header button') }} />
      <text class="section" style={{ marginBottom: 0 }} text={ctx.t('Контейнер без стилей')} />
      <text class="section" style={{ marginBottom: 0 }} text={'<box></box>'} />
      <box style={{ marginHorizontal: 10, padding: 12, border: [1, 'dashed', 'black'], height: 200 }}>
        <box style={{ width: '100%', height: 10, border: [1, 'solid', 'lime'] }} />
        <box style={{ position: 'absolute', left: '88%', bottom: '10%', borderWidth: 3, width: 20, height: 20 }} />
        <box
          style={{
            position: 'absolute',
            left: '91%',
            bottom: '25',
            border: [3, 'solid', 'red'],
            width: 25,
            height: 30,
          }}
        />
      </box>

      <text class="section" style={{ marginBottom: 0, marginTop: 20 }} text={ctx.t('Border width/style/color')} />
      <box
        style={{
          padding: 10,
          borderWidth: [5, 10, 10, 0],
          borderColor: ['green', 'cyan', 'magenta'],
          borderBottomWidth: 2,
          borderRight: ['hairline', 'red'],
          marginHorizontal: 20,
        }}
        onClick={showToast('Hello')}
      />
      <box
        style={{
          padding: 10,
          borderWidth: 5,
          borderColor: 'black',
          borderStyle: 'dashed',
          marginTop: 10,
          marginHorizontal: 20,
        }}
        onClick={showToast('Hello')}
      />

      <text class="section" style={{ marginBottom: 0, marginTop: 20 }} text={ctx.t('Border radius')} />
      <box
        style={{
          height: 50,
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 10,
          backgroundColor: '#e7e1ca',
        }}
      >
        <box style={{ width: 30, height: 30, borderRadius: 5, borderWidth: 2, backgroundColor: '#eee' }} />
        <box style={{ width: 30, height: 30, borderRadius: [3, 6, 12, 20], borderWidth: 2, backgroundColor: '#aaa' }} />
        <box
          style={{
            width: 30,
            height: 30,
            borderTopLeftRadius: 5,
            borderBottomRightRadius: 10,
            borderWidth: 2,
            backgroundColor: '#888',
          }}
        />
      </box>

      <text class="section" style={{ marginBottom: 0, marginTop: 20 }} text={ctx.t('Отрицательный margin')} />
      <box
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 10,
          backgroundColor: '#e7e1ca',
        }}
      >
        <box style={{ border: [1, 'solid', '#000'], padding: 5, width: 30, height: 30, overflow: 'visible' }}>
          <box style={{ marginTop: -10, backgroundColor: '#eee', width: '100%', height: '100%' }}>
            <text style={{ textAlign: 'center' }}>T</text>
          </box>
        </box>
        <box style={{ border: [1, 'solid', '#000'], padding: 5, width: 30, height: 50, overflow: 'visible' }}>
          <box style={{ marginBottom: -10, backgroundColor: '#eee', width: 20, height: 20 }}>
            <text style={{ textAlign: 'center' }}>B</text>
          </box>
          <box style={{ border: [1, 'solid', 'red'], width: 20, height: 20 }} />
        </box>
        <box style={{ border: [1, 'solid', '#000'], padding: 5, width: 30, height: 30, overflow: 'visible' }}>
          <box style={{ marginLeft: -10, backgroundColor: '#eee', width: '100%', height: '100%' }}>
            <text style={{ textAlign: 'center' }}>L</text>
          </box>
        </box>
        <box
          style={{
            border: [1, 'solid', '#000'],
            padding: 5,
            width: 50,
            height: 30,
            overflow: 'visible',
            flexDirection: 'row',
          }}
        >
          <box style={{ marginRight: -10, backgroundColor: '#eee', width: 20, height: 20 }}>
            <text style={{ textAlign: 'center' }}>R</text>
          </box>
          <box style={{ border: [1, 'solid', 'red'], width: 20, height: 20 }} />
        </box>
      </box>

      <text class="section" style={{ marginBottom: 0, marginTop: 20 }} text={ctx.t('Flex')} />
      <text class="section" style={{ marginBottom: 0 }} text={'<box style={{flex: 1}}/>'} />
      <box
        style={{
          height: 40,
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}
      >
        <box style={{ flex: 1, flexBasis: '50%', backgroundColor: 'red' }}>
          <text text="Left" />
        </box>
        <box style={{ flex: -1, minWidth: 5, backgroundColor: 'yellow' }}>
          <text text="Center" />
        </box>
        <box style={{ flex: 0, flexBasis: '60%', backgroundColor: 'green' }}>
          <text text="Right" />
        </box>
      </box>

      <text class="section" style={{ marginBottom: 0, marginTop: 20 }} text={ctx.t('Цвет фона и прозрачность')} />
      <text
        class="section"
        style={{ marginBottom: 0 }}
        text={'<box style={{height: 50, backgrounColor: "red", opacity: 0.5}}/>'}
      />
      <box style={{ height: 50, backgroundColor: 'red', opacity: 0.5 }} />

      <text class="section" style={{ marginBottom: 0, marginTop: 20 }}>
        Смена стиля при клике (:active)
      </text>
      <box
        style={{
          height: 30,
          backgroundColor: '#3b77a9',
          marginHorizontal: 10,
          active: { opacity: 0.5 },
        }}
        onClick={showToast('Клик')}
      />

      <text class="section" style={{ marginBottom: 0, marginTop: 20 }}>
        Вложенные боксы с обработкой клика
      </text>
      <box
        style={{ padding: 50, backgroundColor: '#ddd' }}
        onClick={showToast('Нажали на серый квадрат')}
        onContext={[showToast('Контекст на сером квадрате')]}
      >
        <box style={{ padding: 50, backgroundColor: '#ded' }} onClick={showToast('Нажали на зелёный квадрат')}>
          <box
            style={{ width: 50, height: 50, backgroundColor: '#edd' }}
            onClick={showToast('Нажали на розовый квадрат')}
            onContext={showToast('Контекст на розовом квадрате')}
          />
        </box>
      </box>

      <text class="section" style={{ marginBottom: 0, marginTop: 20 }}>
        nested active styles
      </text>
      <box
        style={{
          padding: 20,
          alignItems: 'flex-end',
          backgroundColor: 'rgb(202,157,202)',
          active: { backgroundColor: 'rgb(210, 0, 210)' },
        }}
        onClick={showToast('Нажали на контейнер')}
      >
        <box
          style={{
            width: 60,
            height: 60,
            alignItems: 'flex-end',
            backgroundColor: 'rgb(198,198,151)',
            active: { backgroundColor: 'rgb(210, 210, 0)' },
          }}
          onClick={showToast('Нажали на кнопочку внутри контейнера')}
        />
      </box>

      <box
        style={{
          marginTop: 10,
          padding: 20,
          alignItems: 'center',
          backgroundColor: 'rgb(202,157,202)',
          active: { backgroundColor: 'rgb(210, 0, 210)' },
          flexDirection: 'row',
        }}
        onClick={showToast('Нажали на контейнер')}
        onContext={showToast('Контекст на контейнере')}
      >
        <box style={{ flexGrow: 1, flexShrink: 1 }}>
          <text style={{ opacity: 0 }}>Этот текст должен быть невидимым всегда</text>
          <text style={{ fontWeight: 'bold', color: 'black', active: { color: 'white' } }}>
            Этот текст внутри контейнера, у которого прописан onClick. Сам контейнер имеет свои активные стили, но
            активные стили также имеются у этого текста и у квадратика справа. При нажатии на контейнер активные стили
            применяются ко всем детям, на всю глубину{'\n'}
            <text style={{ active: { backgroundColor: 'grey' } }}>У этого текста должен добавиться серый фон</text>
          </text>
          <icon
            name={'user'}
            size={'lg'}
            style={{ padding: 5, backgroundColor: 'red', active: { backgroundColor: 'blue' } }}
          />
          <smart-icon
            name={'user'}
            size={'lg'}
            style={{ backgroundColor: 'red', active: { backgroundColor: 'blue' } }}
          />
        </box>
        <box
          style={{
            width: 100,
            height: 100,
            padding: 20,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: 'rgb(208,208,206)',
            active: { backgroundColor: 'rgb(227,227,2)' },
          }}
        >
          <box
            style={{
              width: 60,
              height: 60,
              backgroundColor: 'red',
              active: {
                backgroundColor: 'green',
              },
            }}
            onContext={showToast('Контекст на красном квадрате')}
          />
        </box>
      </box>

      <text class="section" style={{ marginBottom: 0, marginTop: 20 }}>
        backgroundGradients
      </text>
      <box
        style={{
          padding: 20,
          alignItems: 'center',
          backgroundGradient: ['red', 'blue'],
        }}
      >
        <text style={{ color: '#fff' }}>['red', 'blue']</text>
      </box>
      <box
        style={{
          height: 100,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundGradient: [
            ['orange', 0.2],
            ['green', 0.8],
          ],
        }}
      >
        <text style={{ color: '#fff' }}>[['orange', 0.2], ['green', 0.8]]</text>
      </box>
      <box
        style={{
          padding: 20,
          alignItems: 'center',
          backgroundGradient: ['to left', 'red', 'orange', 'yellow', 'green', 'cyan', 'blue', 'purple'],
        }}
      >
        <text style={{ color: '#fff', textShadowColor: '#000', textShadowRadius: 5 }}>
          ['to left', 'red', 'orange', 'yellow', 'green', 'cyan', 'blue', 'purple']
        </text>
      </box>
      <box
        style={{
          padding: 20,
          alignItems: 'center',
          backgroundGradient: [90, ['orange', 0.25], ['green', 0.5]],
        }}
      >
        <text style={{ color: '#fff' }}>[90, ['orange', 0.25], ['green', 0.5]]</text>
      </box>
      <box
        style={{
          padding: 20,
          alignItems: 'center',
          backgroundGradient: ['to right', ['red', 0.4], ['blue', 0.6]],
        }}
      >
        <text style={{ color: '#fff' }}>['to right', ['red', 0.4], ['blue', 0.6]]</text>
      </box>
      <box
        style={{
          padding: 20,
          alignItems: 'center',
          backgroundGradient: [-90, 'orange', 'green'],
        }}
      >
        <text style={{ color: '#fff' }}>[-90, 'orange', 'green']</text>
      </box>
      <box
        style={{
          padding: 50,
          alignItems: 'center',
          backgroundGradient: [135, 'red', 'blue'],
        }}
      >
        <text style={{ color: '#fff' }}>[135, 'red', 'blue']</text>
      </box>
      <box
        style={{
          padding: 20,
          alignItems: 'center',
          backgroundGradient: ['to top', 'orange', 'green'],
        }}
      >
        <text style={{ color: '#fff' }}>['to top', 'orange', 'green']</text>
      </box>
      <box
        style={{
          padding: 20,
          alignItems: 'center',
          backgroundGradient: [60, 'red', ['green', 0.5], ['green', 0.9], 'blue'],
        }}
      >
        <text style={{ color: '#fff' }}>[60, 'red', ['green', 0.5], ['green', 0.9], 'blue']</text>
      </box>
      <box
        style={{
          alignSelf: 'center',
          alignItems: 'center',
          justifyContent: 'center',
          width: 300,
          height: 300,
          backgroundGradient: [45, ['pink', 0.4], ['purple', 0.6]],
        }}
      >
        <text style={{ color: '#fff' }}>[45, ['pink', 0.4], ['purple', 0.6]]</text>
      </box>
    </screen>
  )
})
