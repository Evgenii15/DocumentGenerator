import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="Transform">
      <text text={ctx.t('Scale')} />
      <text text={'<box style={{ transform: [{ scale: 1.5 }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ scale: 1.5 }] }]}>
          <text text={'Scale 1.5'} />
        </box>
      </box>

      <text text={ctx.t('ScaleX')} />
      <text text={'<box style={{ transform: [{ scaleX: 1.5 }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ scaleX: 1.5 }] }]}>
          <text text={'ScaleX 1.5'} />
        </box>
      </box>

      <text text={ctx.t('ScaleY')} />
      <text text={'<box style={{ transform: [{ scaleY: 1.5 }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ scaleY: 1.5 }] }]}>
          <text text={'ScaleY 1.5'} />
        </box>
      </box>

      <text text={ctx.t('Rotate')} />
      <text text={'<box style={{ transform: [{ rotate: "45deg" }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ rotate: '45deg' }] }]}>
          <text text={'Rotate 45deg'} />
        </box>
        <box style={[s.innerBox, { transform: [{ rotate: '-1rad' }] }]}>
          <text text={'Rotate -1rad'} />
        </box>
        <box style={[s.innerBox, { transform: [{ rotate: '90deg' }] }]}>
          <text text={'Rotate 90deg'} />
        </box>
      </box>

      <text text={ctx.t('RotateX')} />
      <text text={'<box style={{ transform: [{ rotateX: "45deg" }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ rotateX: '45deg' }] }]}>
          <text text={'RotX 45deg'} />
        </box>
      </box>

      <text text={ctx.t('RotateY')} />
      <text text={'<box style={{ transform: [{ rotateY: "45deg" }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ rotateY: '45deg' }] }]}>
          <text text={'RotY 45deg'} />
        </box>
      </box>

      <text text={ctx.t('RotateZ')} />
      <text text={'<box style={{ transform: [{ rotateZ: "45deg" }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ rotateZ: '45deg' }] }]}>
          <text text={'RotZ 45deg'} />
        </box>
      </box>

      <text text={ctx.t('Perspective')} />
      <text text={'<box style={{ transform: [{perspective: 150}, { rotateY: "45deg" }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ perspective: 150 }, { rotateY: '45deg' }] }]}>
          <text text={'Perspec'} />
        </box>
      </box>

      <text text={ctx.t('TranslateX/TranslateY')} />
      <text text={'<box style={{ transform: [{ translateX: 100 }, { translateY: 40 }] }}/>'} />
      <box style={s.container}>
        <box style={[s.innerBox, s.absolute]}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, s.absolute, { transform: [{ translateX: 100 }, { translateY: 40 }] }]}>
          <text text={'TransX/Y'} />
        </box>
      </box>

      <text text={ctx.t('SkewX')} />
      <text text={'<box style={{ transform: [{ skewX: "30deg" }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ skewX: '30deg' }] }]}>
          <text text={'SkX 30deg'} />
        </box>
      </box>

      <text text={ctx.t('SkewY')} />
      <text text={'<box style={{ transform: [{ skewY: "30deg" }] }}/>'} />
      <box style={s.container}>
        <box style={s.innerBox}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, { transform: [{ skewY: '30deg' }] }]}>
          <text text={'SkY 30deg'} />
        </box>
      </box>

      <text text={ctx.t('Matrix')} />
      <text text={'<box style={{ transform: [{ matrix: [1, 0.5, -1, 1, 200, 20] }] }}/>'} />
      <box style={s.container}>
        <box style={[s.innerBox, s.absolute]}>
          <text text={'Origin'} />
        </box>
        <box style={[s.innerBox, s.absolute, { transform: [{ matrix: [1, 0.5, -1, 1, 200, 20] }] }]}>
          <text text={'Matrix'} />
        </box>
      </box>

    </screen>
  )
})


const s = {
  container: {
    height: 100,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#e7e1ca',
  } as BoxStyle,
  innerBox: {
    width: 50,
    height: 50,
    borderWidth: 1,
    backgroundColor: '#eeb2b2',
    alignItems: 'center',
    justifyContent: 'center',
  } as BoxStyle,
  absolute: { position: 'absolute', left: 0, top: 0 } as BoxStyle,
}
