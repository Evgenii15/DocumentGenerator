import {showToast} from '@chatium/json'

function Example(props, ...children) {
  return <>
    <text>{props.title}</text>
    {children}
  </>
}

app.screen('/', function (ctx, req) {

  ctx.t = v => v
  const IMAGE_URL = 'https://cdn.pixabay.com/photo/2020/05/15/18/46/corona-5174671_1280.jpg'

  return (
    <screen title="Hello world!">
      <Example title={ctx.t('Высота')}>
        <list-item
          icon={{ name: ['fas', 'laptop'], class: 'circle', style: { borderWidth: 1 } }}
          content={{
            title: 'style.height=lg',
            subTitle: ctx.t('Высота явно задана для корневого элемента, на неё не влияет контент'),
          }}
          style={{
            height: 'lg',
            borderColor: '#ddd',
            borderWidth: [1, 0],
          }}
        />
        <list-item
          icon={{ size: 'xl', name: ['fas', 'laptop'], class: 'circle', style: { borderWidth: 1 } }}
          content={{
            title: 'icon.size=xl style.height=undefined',
            subTitle: ctx.t(
              'Минимальная высота определена размером иконки, но может быть увеличена стилями текста (см ниже)',
            ),
          }}
          style={{ borderBottom: [1, '#ddd'], lineClamp: 1 }}
        />
        <list-item
          icon={{ size: 'md', name: ['fas', 'laptop'], class: 'circle', style: { borderWidth: 1 } }}
          content={{
            title: 'icon.size=md\nstyle.fontSize=20\nstyle.lineClamp=3',
            subTitle: ctx.t('Контент определяет высоту айтема'),
          }}
          style={{ borderBottom: [1, '#ddd'], fontSize: 20, lineClamp: 3 }}
        />
        <list-item
          icon={{ size: 'sm', name: ['fas', 'laptop'], class: 'circle', style: { borderWidth: 1 } }}
          content={{
            title: 'icon.size=sm style.paddingVertical=20',
            subTitle: (
              <text style={{ lineClamp: 3 }}>
                {ctx.t('Явно заданный паддинг влияет на высоту айтема в дополнение к высоте контента или иконки')}
              </text>
            ),
          }}
          style={{ borderBottom: [1, '#ddd'], paddingVertical: 20 }}
        />
        <list-item
          icon={{ name: ['fas', 'laptop'], class: 'circle', style: { borderWidth: 2 } }}
          content={{
            title: ctx.t('Не заданы style.height и icon.size'),
            subTitle: ctx.t('Размер иконки по умолчанию - md'),
          }}
          style={{
            borderBottom: [1, '#ddd'],
          }}
        />
        <list-item
          content={{
            title: ctx.t('Нет иконки и высота не задана, xxxxxxxxxxxxxxxxxxx'),
            subTitle: ctx.t('Высота по двум строчкам заголовок + подзаголовок, xxxxxx'),
          }}
          style={{
            borderBottom: [1, '#ddd'],
          }}
        />
      </Example>

      <Example title={ctx.t('Разные комбинации контента / автоподбор количества строк')}>
        <list-item
          icon={{ name: ['fas', 'laptop'], class: 'circle', style: { borderWidth: 1 } }}
          content={{
            title: ctx.t('style.height=sm По одной стоке отображается'),
            subTitle: ctx.t('Даже если не хватает высоты'),
          }}
          style={{
            height: 'sm',
            borderColor: '#ddd',
            borderWidth: [1, 0],
          }}
        />
        <list-item
          icon={{ name: ['far', 'user'], class: 'square', style: { color: '#fff', backgroundColor: '#9984a9' } }}
          content={{
            title: ctx.t('style.height=lg Автоподбор количества строк контента'),
            rightMinitext: '23 июня 2002',
            subTitle: ctx.t('Вы: Если у вас возникнут какие-то вопросы, то обязательно напишите нам'),
            badge: '99+',
          }}
          style={{
            height: 'lg',
            borderBottom: [1, '#ddd'],
          }}
        />
        <list-item
          icon={{ name: ['far', 'user'], class: 'square', style: { color: '#fff', backgroundColor: '#9984a9' } }}
          content={{
            title: ctx.t('style.height=lg\nstyle.lineClamp=2'),
            subTitle: ctx.t('Строки подзаголовка адаптировались'),
            badge: '99+',
          }}
          style={{
            height: 'lg',
            lineClamp: 2,
            borderBottom: [1, '#ddd'],
          }}
        />
        <list-item
          icon={{ name: ['fas', 'laptop'], class: 'circle', style: { borderWidth: 1 } }}
          content={{
            title: ctx.t('style.height=xl Строчки распределяются равномерно'),
            subTitle: ctx.t('Но преимущество отдаётся подзаголовку (на 1 больше или равно)'),
          }}
          style={{
            height: 'xl',
            borderBottom: [1, '#ddd'],
          }}
        />
        <list-item
          icon={{ name: ['fas', 'laptop'], class: 'circle', style: { borderWidth: 1 } }}
          content={{
            title: ctx.t('style.height=xl style.fontSize=sm\nШрифт влияет'),
            subTitle: ctx.t(
              'Количество строк можно увеличить, уменьшив размер шрифта. Размер шрифта подзаголовка, метки справа и беджа адаптируются по отношению к шрифту заголовка',
            ),
          }}
          style={{
            height: 'xl',
            fontSize: 'sm',
            borderBottom: [1, '#ddd'],
          }}
        />
        <list-item
          icon={{ name: ['fas', 'laptop'], class: 'circle', style: { borderWidth: 1 } }}
          content={{
            title: ctx.t('+style.lineClamp=1 Явно заданное количество строк'),
            subTitle: ctx.t(
              'Если явно задать количество строк заголовка, то для подзаголовка будет выделено всё оставшееся место автоматом',
            ),
          }}
          style={{
            height: 'xl',
            fontSize: 'sm',
            lineClamp: 1,
            borderBottom: [1, '#ddd'],
          }}
        />
        <list-item
          icon={{ name: ['fas', 'laptop'], class: 'circle', style: { color: '#000', backgroundColor: '#e5d4a3' } }}
          content={{
            title: ctx.t(
              'style.height=lg Только заголовок, должно быть 3 строки по идее, длинный тайтл чтобы места не хватило, раз-два-три трам-пам-пам',
            ),
          }}
          style={{
            height: 'lg',
            borderBottom: [1, '#ddd'],
          }}
        />
        <list-item
          icon={{
            text: 'Д.Г.',
            class: 'circle',
            style: { borderWidth: 2 },
            badges: {
              name: ['fas', 'pray'],
              class: 'circle',
              style: {
                backgroundColor: '#e5d4a3',
                color: 'red',
              },
            },
          }}
          content={{
            subTitle: ctx.t('md - Только длинный подзаголовок, посмотрим как это работает'),
          }}
          style={{
            borderBottom: [1, '#ddd'],
          }}
        />
        <list-item
          icon={{ url: IMAGE_URL, class: 'circle' }}
          content={{
            title: ctx.t('Только заголовок с беджиком, беджик справа'),
            badge: {
              badge: 3,
              style: {
                backgroundColor: '#888',
              },
            },
          }}
          style={{
            height: 'sm',
            borderBottom: [1, '#ddd'],
          }}
        />
      </Example>

      <Example title={ctx.t('Типа меню + клики')}>
        <list-item
          icon={{
            name: ['fas', 'bell'],
            size: 'sm',
          }}
          content={{
            title: ctx.t('icon.size=sm Уведомления'),
            badge: 1,
          }}
          onClick={'/inbox'}
        />
        <list-item
          icon={{
            name: ['fas', 'bell'],
            size: 'sm',
          }}
          content={{
            title: ctx.t('class=selected'),
            badge: 1,
          }}
          class="selected"
        />
        <list-item
          icon={{
            name: ['fas', 'sign-in-alt'],
            class: 'circle',
            style: {
              backgroundColor: '#d4c9b1',
            },
          }}
          content={{
            title: ctx.t('style.height=sm Личный кабинет'),
          }}
          style={{ height: 'sm' }}
          onClick={'/app/cabinet'}
        />
        <list-item
          icon={{
            name: ['fas', 'user'],
            size: 'sm',
            class: 'square',
            style: {
              borderWidth: 1,
            },
          }}
          content={{
            title: ctx.t('onContext=showToast Аккаунты пользователей'),
          }}
          onContext={showToast('Правая кнопка')}
        />
        <list-item
          icon={{
            name: ['fas', 'bars'],
            size: 'sm',
          }}
          content={{
            title: ctx.t('style.active.backgroundColor=#999'),
            badge: '',
          }}
          onClick={'/'}
          style={{
            active: { backgroundColor: '#999' },
          }}
        />
      </Example>

      <Example title={ctx.t('Кастомизация')}>
        <list-item
          icon={{ name: ['fas', 'sms'] }}
          content={{
            title: ctx.t('customContent=<icon/> style.backgroundGradient=[...]'),
            subTitle: 'Иконка справа + градиентный фон',
          }}
          customContent={<icon name={['fas', 'angle-right']} size={30} style={{ color: '#888' }} />}
          onClick={'/inbox'}
          style={{
            height: 'lg',
            paddingRight: 0,
            backgroundGradient: ['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0.1)'],
          }}
        />
        <list-item
          icon={{ name: ['fas', 'chess'] }}
          style={{
            height: 'lg',
            backgroundGradient: ['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0.1)'],
          }}
        >
          <icon name={['fas', 'chess-queen']} style={{ color: 'red' }} />
          <text style={{ lineClamp: 3 }}>
            Полностью <text style={{ fontWeight: 'bold' }}>кастомный</text> контент: children=[icon, text, Box] (кроме
            левой иконки)
          </text>
          <box style={{ height: '100%', width: '50', borderRadius: 10, border: [2, 'solid', 'green'] }} />
        </list-item>
        <list-item
          icon={{ text: 'A', size: 'lg', class: 'circle', style: { backgroundColor: '#e5dab0' } }}
          content={{
            title: 'Синяя точка рядом с правым текстом',
            subTitle: (
              <text style={{ lineClamp: 3 }}>
                {
                  'rightMinitext=<text class="list-itemRightMinitext">12:18 <text style={{color: "#0F7AF6"}}>●</text></text>'
                }
              </text>
            ),
            rightMinitext: (
              <text class="list-itemRightMinitext">
                12:18 <text style={{ color: '#0F7AF6' }}>●</text>
              </text>
            ),
          }}
          style={{
            lineClamp: 1,
            backgroundGradient: ['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0.1)'],
          }}
        />
        <list-item
          content={{
            title: 'content.badge.style.height=25',
            rightMinitext: 'вчера',
            subTitle: (
              <text style={{ lineClamp: 2 }}>{ctx.t('Шрифт беджика адаптируется к явно-заданной высоте')}</text>
            ),
            badge: {
              badge: 113,
              style: {
                height: 25,
                backgroundColor: 'transparent',
                border: [2, 'solid', 'red'],
                color: 'red',
                alignSelf: 'flex-start',
              },
            },
          }}
          style={{
            lineClamp: 1,
            backgroundGradient: ['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0.1)'],
          }}
        />
        <list-item
          icon={{ name: 'user' }}
          content={{
            title: ctx.t('Нежирный title'),
            subTitle: 'style.fontWeight=normal',
          }}
          style={{
            fontWeight: 'normal',
            backgroundGradient: ['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0.1)'],
          }}
        />
      </Example>

      <Example title={ctx.t('Стилизация активного состояния')}>
        <list-item
          icon={{ name: 'user' }}
          content={{
            title: ctx.t('Фоновый градиент заменить активным цветом при нажатии нельзя'),
          }}
          style={{
            backgroundGradient: ['orange', 'green'],
            active: {
              backgroundColor: '#bcddcf',
            },
          }}
          onClick={showToast(ctx.t('Клик'))}
        />
        <list-item
          icon={{ name: 'user' }}
          content={{
            title: ctx.t('Но под полупрозрачным градиентом фоновый цвет будет виден'),
          }}
          style={{
            backgroundGradient: ['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0.1)'],
            active: {
              backgroundColor: '#bcddcf',
            },
          }}
          onClick={showToast(ctx.t('Клик'))}
        />
        <list-item
          icon={{
            name: 'user',
            style: {
              active: {
                backgroundColor: 'orange',
              },
            },
          }}
          content={{
            title: ctx.t('Можно стилизовать активное состояние заголовка'),
            subTitle: (
              <text
                class="list-itemSubTitle"
                text="У подзаголовка и иконки тоже"
                style={{
                  active: {
                    color: '#a5e3dd',
                  },
                }}
              />
            ),
          }}
          style={{
            active: {
              backgroundColor: '#4f87b0',
              color: '#fff',
            },
          }}
          onClick={showToast(ctx.t('Клик'))}
        />
      </Example>
    </screen>
  )
})
