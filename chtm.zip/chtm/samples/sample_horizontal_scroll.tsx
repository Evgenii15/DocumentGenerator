import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="Horizontal scroll">
      <header
        title={ctx.t('Блоки > {type}', { type: 'HORIZONTAL-SCROLL' })}
        rightButton={{ onClick: showToast('header button') }}
      />
      <text>Простой примера горизонтально-скроллируемого контейнера</text>
      <horizontal-scroll style={{ marginVertical: 10 }}>
        <text style={{ padding: 20, backgroundColor: COLORS[0] }}>Это первый элемент</text>
        <text style={{ padding: 20, backgroundColor: COLORS[1], textAlign: 'center' }} onClick={showToast('Клик')}>
          Это второй элемент{'\n'}(кликабельный)
        </text>
        <box style={{ padding: 20, backgroundColor: COLORS[2] }}>
          <text>Это третий элемент</text>
        </box>
      </horizontal-scroll>

      <text>Добавление стилей к блоку</text>
      <horizontal-scroll
        style={{ marginVertical: 10, border: [2, 'solid', 'black'], padding: 10, backgroundColor: '#eee' }}
      >
        <text style={{ padding: 20, backgroundColor: COLORS[0] }}>Это первый элемент</text>
        <text style={{ padding: 20, backgroundColor: COLORS[1] }}>Это второй элемент</text>
        <box style={{ padding: 20, backgroundColor: COLORS[2] }}>
          <text>Это третий элемент</text>
        </box>
      </horizontal-scroll>

      <text>Ширина каждого элемента - 100%, листалка слайдами</text>
      <horizontal-scroll snapToBlocks={true}>
        <text style={{ width: '100%', padding: 20, backgroundColor: COLORS[0] }}>Это первый элемент</text>
        <text style={{ width: '100%', padding: 20, backgroundColor: COLORS[1] }}>Это второй элемент</text>
        <box style={{ width: '100%', padding: 20, backgroundColor: COLORS[2] }}>
          <text>Это третий элемент</text>
        </box>
      </horizontal-scroll>

      <text>Ширина каждого элемента - 40%</text>
      <horizontal-scroll>
        <box
          style={{
            width: '40%',
            padding: 20,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: COLORS[0],
          }}
        >
          <text>1</text>
        </box>
        <box
          style={{
            width: '40%',
            padding: 20,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: COLORS[1],
          }}
        >
          <text>2</text>
        </box>
        <box
          style={{
            width: '40%',
            padding: 20,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: COLORS[2],
          }}
        >
          <text>3</text>
        </box>
        <box
          style={{
            width: '40%',
            padding: 20,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: COLORS[3],
          }}
        >
          <text>4</text>
        </box>
        <box
          style={{
            width: '40%',
            padding: 20,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: COLORS[4],
          }}
        >
          <text>5</text>
        </box>
      </horizontal-scroll>

      <text>Галерея картинок</text>
      <horizontal-scroll snapToBlocks={true}>
        <box style={{ width: '100%' }}>
          <image src={{ url: getImage(0, 400) }} />
        </box>
        <box style={{ width: '100%' }}>
          <image src={{ url: getImage(1, 400) }} />
        </box>
        <box style={{ width: '100%' }}>
          <image src={{ url: getImage(2, 400) }} />
        </box>
        <box style={{ width: '100%' }}>
          <image src={{ url: getImage(3, 400) }} />
        </box>
      </horizontal-scroll>

      <text>Галерея фото-карточек</text>
      <horizontal-scroll snapToBlocks={true} class={'section'} style={{ paddingRight: 10 }}>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_CDWWY3HDec.640x427.jpeg/s/758x504' }}
            style={{ borderRadius: 10 }}
          />
        </box>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_sDDAkpI9tf.640x427.jpeg/s/758x504' }}
            style={{ borderRadius: 10 }}
          />
        </box>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_5KZIcpQ8s0.640x427.jpeg/s/758x504' }}
            style={{ borderRadius: 10 }}
          />
        </box>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_BppEMeEAvw.640x427.jpeg/s/758x504' }}
            style={{ borderRadius: 10 }}
          />
        </box>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_qKjIqPGvVs.640x427.jpeg/s/758x504' }}
            style={{ borderRadius: 10 }}
          />
        </box>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_kDfZnxB6NM.640x427.jpeg/s/758x504' }}
            style={{ borderRadius: 10 }}
          />
        </box>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_1B9Jh2FSHa.640x427.jpeg/s/758x504' }}
            style={{ borderRadius: 10 }}
          />
        </box>
      </horizontal-scroll>

      <text>Галерея банковских карточек</text>
      <horizontal-scroll snapToBlocks={true} class={'section'} style={{ paddingRight: 10 }}>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_Dbt4FzAV9H.728x454.jpeg/s/758x472' }}
          />
        </box>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_w1yQAIMAD6.728x454.jpeg/s/758x472' }}
          />
        </box>
        <box style={{ width: '95%', paddingLeft: 10 }}>
          <image
            src={{ url: 'https://fs.chatium.io/fileservice/file/thumbnail/h/image_iigHuRFu5N.728x454.jpeg/s/758x472' }}
          />
        </box>
      </horizontal-scroll>

    </screen>
  )
})


const COLORS = ['rgb(231,173,173)', 'rgb(150,236,150)', 'rgb(144,144,219)', 'rgb(214,144,219)', 'rgb(203,219,144)']

const IMAGES = [
  `https://picsum.photos/seed/chatium-image-1/600`,
  `https://picsum.photos/seed/chatium-image-2/600`,
  `https://picsum.photos/seed/chatium-image-3/600`,
  `https://picsum.photos/seed/chatium-image-4/600`,
  `https://picsum.photos/seed/chatium-image-5/600`,
  `https://picsum.photos/seed/chatium-image-6/600`,
  `https://picsum.photos/seed/chatium-image-7/600`,
  `https://picsum.photos/seed/chatium-image-8/600`,
]

function getImage(index: number, height: number) {
  return IMAGES[index] + '/' + height
}
