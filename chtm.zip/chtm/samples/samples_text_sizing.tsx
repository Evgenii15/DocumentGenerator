import { showToast } from '@chatium/json'

app.screen('/', function (ctx, req) {

  ctx.t = v => v

  return (
    <screen title="Hello world!">
      <text class={'section'} style={{ marginBottom: 0 }}>
        Текст с границей:
      </text>
      <text
        style={{
          margin: 10,
          marginBottom: 20,
          padding: 10,
          backgroundColor: '#ddd',
          border: ['hairline', 'solid', '#888'],
        }}
      >
        Этот текст в рамке
      </text>

      <text class={'section'} style={{ marginBottom: 0 }}>
        Текст с границей со скруглёнными углами:
      </text>
      <text
        style={{
          margin: 10,
          padding: 10,
          backgroundColor: '#ddd',
          border: ['hairline', 'solid', '#888'],
          borderRadius: 10,
          marginBottom: 20,
        }}
      >
        Этот текст в рамке со скруглёнными углами
      </text>

      <text class="section" style={{ marginBottom: 0 }}>
        Круглый бейджик с помощью border/borderRadius
      </text>
      <text
        style={{
          border: [1, 'solid', 'darkblue'],
          backgroundColor: '#699ce7',
          borderRadius: 1000,
          height: 30,
          color: 'white',
          fontWeight: 'bold',
          alignSelf: 'flex-start',
          marginBottom: 20,
          textAlign: 'center',
          textAlignVertical: 'center',
          paddingHorizontal: 10,
          marginHorizontal: 10,
        }}
      >
        5
      </text>

      <text class="section" style={{ marginBottom: 0 }}>
        Явное задание ширины и высоты блоку, и выравнивание текста внутри
      </text>
      <text
        style={{
          margin: 10,
          padding: 10,
          backgroundColor: '#ddd',
          width: '50%',
          height: 200,
          textAlign: 'left',
          textAlignVertical: 'top',
          alignSelf: 'flex-start',
        }}
      >
        width: 50%, height: 200, textAlign: left, textAlignVertical: top, alignSelf: flex-start
      </text>
      <text
        style={{
          margin: 10,
          padding: 10,
          backgroundColor: '#ddd',
          width: '50%',
          height: 200,
          textAlign: 'center',
          textAlignVertical: 'center',
          alignSelf: 'center',
        }}
      >
        width: 50%, height: 200, textAlign: center, textAlignVertical: center, alignSelf: center
      </text>
      <text
        style={{
          margin: 10,
          padding: 10,
          backgroundColor: '#ddd',
          width: '50%',
          height: 200,
          textAlign: 'right',
          textAlignVertical: 'bottom',
          alignSelf: 'flex-end',
        }}
      >
        width: 50%, height: 200, textAlign: right, textAlignVertical: bottom, alignSelf: flex-end
      </text>

      <text class="section" style={{ marginBottom: 0 }}>
        Блоки с разными уголками
      </text>
      <text
        style={{
          padding: 10,
          marginHorizontal: 10,
          borderTopLeftRadius: 20,
          borderTopRightRadius: 20,
          borderWidth: 'hairline',
          borderColor: '#888',
          backgroundColor: '#ddd',
        }}
      >
        Верхняя часть
      </text>
      <text
        style={{
          padding: 10,
          marginHorizontal: 10,
          marginBottom: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
          borderWidth: 'hairline',
          borderColor: '#555',
          backgroundColor: '#aaa',
        }}
      >
        Нижняя часть
      </text>

      <text class="section" style={{ marginBottom: 0 }}>
        А вот так можно эмулировать кнопку:
      </text>
      <text
        style={{
          marginHorizontal: 10,
          padding: 10,
          backgroundColor: '#0379FE',
          color: 'white',
          fontSize: 18,
          textAlign: 'center',
          borderRadius: 8,
          marginBottom: 20,
          active: {
            opacity: 0.7,
          },
        }}
        onClick={{ type: 'showToast', toast: 'Вы нажали на кнопку' }}
      >
        Это кнопка, нажми меня
      </text>
    </screen>
  )
})
